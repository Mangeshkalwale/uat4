<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';


class User extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('user_model');
        $this->load->model('cust_model');
        $this->load->model('lr_model');
        $this->load->model('invoice_model');
        $this->load->library('pdf');
        $this->isLoggedIn();   
        $this->session->keep_flashdata('message');
    }
    
    /**
     * This function used to load the first screen of the user
     */
    public function index()
    {


        $data['lrcount']= $this->user_model->lrcount();
        $data['invoicecount']= $this->user_model->invoicecount();
        $data['customercount']= $this->user_model->custcount();
        $data['paymentcount']= $this->user_model->paymentcount();
        $today=date('Y-m-d');

        $data['invRecords']=$this->invoice_model->getdueinvoice($today);

        $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->lr_model->lrListingCount($searchText);

            $returns = $this->paginationCompress ( "lrListing/", $count, 10 );
            
            $data['lrRecords'] = $this->lr_model->lrListingdash($searchText, $returns["page"], $returns["segment"]);
            
        

        $this->global['pageTitle'] = 'Shaurya Enterprises : Dashboard';
        
        $this->loadViews("dashboard", $this->global, $data , NULL);
    }
    
    /**
     * This function is used to load the user list
     */
    function userListing()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {        
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->user_model->userListingCount($searchText);

			$returns = $this->paginationCompress ( "userListing/", $count, 10 );
            
            $data['userRecords'] = $this->user_model->userListing($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'Shaurya Enterprises : User Listing';
            
            $this->loadViews("users", $this->global, $data, NULL);
        }
    }



    /*This function is for load the customer list*/
    function custListing()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {        
            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->cust_model->custListingCount($searchText);

            $returns = $this->paginationCompress ( "custListing/", $count, 10 );
            
            $data['custRecords'] = $this->cust_model->custListing($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'Shaurya Enterprises : User Listing';
            
            $this->loadViews("customers", $this->global, $data, NULL);
        }
    }


/*This function is for load the LR list*/
    function lrListing()
    {
        /*if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }*/
        /*else
        {        
        */    $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->lr_model->lrListingCount($searchText);

            $returns = $this->paginationCompress ( "lrListing/", $count, 10 );
            
            $data['lrRecords'] = $this->lr_model->lrListing($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'Shaurya Enterprises : User Listing';
            
            $this->loadViews("viewlr", $this->global, $data, NULL);
        /*}*/
    }

    function dashboardlrListing()
    {
        /*if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }*/
        /*else
        {        
        */    $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->lr_model->lrListingCount($searchText);

            $returns = $this->paginationCompress ( "lrListing/", $count, 10 );
            
            $data['lrRecords'] = $this->lr_model->lrListing($searchText, $returns["page"], $returns["segment"]);
            
            
            
            
        /*}*/
    }

    /**
     * This function is used to load the add new form
     */
    function addNew()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('user_model');
            $data['roles'] = $this->user_model->getUserRoles();
            
            $this->global['pageTitle'] = 'Shaurya Enterprises : Add New User';

            $this->loadViews("addNew", $this->global, $data, NULL);
        }
    }

/*function for add new customer*/
function addNewcust()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('Cust_model');
            $data['roles'] = $this->Cust_model->getUserRoles();
            
            $this->global['pageTitle'] = 'Shaurya Enterprises : Customer management';

            $this->loadViews("customermanagement", $this->global, $data, NULL);
        }
    }
    


    /**
     * This function is used to check whether email already exist or not
     */
    function checkEmailExists()
    {
        $userId = $this->input->post("userId");
        $email = $this->input->post("email");

        if(empty($userId)){
            $result = $this->user_model->checkEmailExists($email);
        } else {
            $result = $this->user_model->checkEmailExists($email, $userId);
        }

        if(empty($result)){ echo("true"); }
        else { echo("false"); }
    }

function checkcustExists()
    {
        $GSTIN = $this->input->post("GSTNO");
        

        
            $result = $this->user_model->checkEmailExists($GSTIN);
        
        
        

        if(empty($result)){ echo("true"); }
        else { echo("false"); }
    }

     function checkEmailExistscust()
    {
        $userId = $this->input->post("userId");
        $email = $this->input->post("email");

        if(empty($userId)){
            $result = $this->user_model->checkEmailExists($email);
        } else {
            $result = $this->user_model->checkEmailExists($email, $userId);
        }

        if(empty($result)){ echo("true"); }
        else { echo("false"); }
    }
    

    
    /**
     * This function is used to add new user to the system
     */
    function addNewUser()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('fname','Full Name','trim|required|max_length[128]');
            $this->form_validation->set_rules('email','Email','trim|required|valid_email|max_length[500]');
            $this->form_validation->set_rules('password','Password','required|max_length[20]');
            $this->form_validation->set_rules('cpassword','Confirm Password','trim|required|matches[password]|max_length[20]');
            $this->form_validation->set_rules('role','Role','trim|required|numeric');
            $this->form_validation->set_rules('status','Status','trim|required');
            $this->form_validation->set_rules('mobile','Mobile Number','required|min_length[10]');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->addNew();
            }
            else
            {
                $name = ucwords(strtolower($this->security->xss_clean($this->input->post('fname'))));
                $email = strtolower($this->security->xss_clean($this->input->post('email')));
                $password = $this->input->post('password');
                $roleId = $this->input->post('role');
                $status=$this->security->xss_clean($this->input->post('status'));
                $mobile = $this->security->xss_clean($this->input->post('mobile'));
                
                $userInfo = array('email'=>$email, 'password'=>getHashedPassword($password), 'roleId'=>$roleId, 'name'=> $name,
                                    'mobile'=>$mobile, 'createdBy'=>$this->vendorId,'status'=>$status, 'createdDtm'=>date('Y-m-d H:i:s'));
                
                $this->load->model('user_model');
                $result = $this->user_model->addNewUser($userInfo);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'New User created successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'User creation failed');
                }
                
                redirect('addNew');
            }
        }
    }

    
    /**
     * This function is used load user edit information
     * @param number $userId : Optional : This is user id
     */
    function editOld($userId = NULL)
    {
        if($this->isAdmin() == TRUE )
        {
            $this->loadThis();
        }
        else
        {
            if($userId == null)
            {
                redirect('userListing');
            }
            
            $data['roles'] = $this->user_model->getUserRoles();
            $data['userInfo'] = $this->user_model->getUserInfo($userId);
            
            $this->global['pageTitle'] = 'Shaurya Enterprises : Edit User';
            
            $this->loadViews("editOld", $this->global, $data, NULL);
        }
    }
    
    
    /**
     * This function is used load customer edit information
     * @param number $userId : Optional : This is user id
     */
    function editOldcust($id = NULL)
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            if($id == null)
            {
                redirect('custListing');
            }
            $ctype = $this->user_model->getcusttype($id);
            $data['cities']=$this->user_model->getcities();

            if($ctype=="Regular")
            {

            $data['roles'] = $this->user_model->getUserRoles();
            $data['custInfo'] = $this->user_model->getcustInfo($id);

            $data['custtypes'] = $this->user_model->getcusttypes();
            
            $this->global['pageTitle'] = 'Shaurya Enterprises : Edit User';
            
            $this->loadViews("editOldcust", $this->global, $data, NULL);
            }
            elseif($ctype=="Contract")
            {
                $data['roles'] = $this->user_model->getUserRoles();
            $data['custInfo'] = $this->user_model->getcustInfo($id);

            $data['custtypes'] = $this->user_model->getcusttypes();
            
            $this->global['pageTitle'] = 'Shaurya Enterprises : Edit User';
            
            $this->loadViews("editOldcustc", $this->global, $data, NULL);

            }
            else
            {
              $this->session->set_flashdata('error', 'Customer Type Not found.Recreate  Customer with valid Type');  
              redirect('custListing');

            }

        }
    }



/**
     * This function is used load New LR creation dashboard
     * @param number $userId : Optional : This is user id
     */
    function lr($id = NULL)
    {
        /*if($this->isAdmin() == TRUE || $id == 1)
        {
            $this->loadThis();
        }*/
       /* else
        {
          */  if($id == null)
            {
                redirect('lrListing');
            }
            
            $data['roles'] = $this->user_model->getUserRoles();
            $data['custInfo'] = $this->user_model->getcustInfo($id);
            $data['cities']=$this->user_model->getcities();
            $data['vehicles']=$this->user_model->getvehicles();
            
            $this->global['pageTitle'] = 'Shaurya Enterprises : Edit User';
            
            $this->loadViews("editlr", $this->global, $data, NULL);
        /*}*/
    }



/**
     * This function is used load created lr
     * @param number $userId : Optional : This is user id
     */
    function lrview($id = NULL,$custid=null)
    {
        /*if($this->isAdmin() == TRUE || $id == 1)
        {
            $this->loadThis();
        }*/
        /*else
        {
        */
                

            if($id == null & $custid == null)
            {
                redirect('lrListing');
            }
            $ctype = $this->user_model->getcusttype($custid);

            if($ctype=='Regular')
            {
             $data['createdby']=$_SESSION["name"];
            $data['compinfo']=$this->user_model->getcompinfo();
          
            $data['lrinfo'] = $this->lr_model->getlrInfop($id);
            
            $this->global['pageTitle'] = 'Shaurya Enterprises : Edit User';


            $this->pdf->load_view('mypdf',$data,$id);
            }

            else
            {
                $data['compinfo']=$this->user_model->getcompinfo();
                $data['lrinfo'] = $this->lr_model->getlrInfop($id);
                $datap = $this->lr_model->getlrInfoftv($id);
                $fromc=$datap->city;
                $toc=$datap->consigneecity;
                $vtype=$datap->vtype;

                $data['getfreightc']=$this->lr_model->getfreightc($fromc,$toc,$vtype,$custid);
                $data['createdby']=$_SESSION["name"];

                
            
            $this->global['pageTitle'] = 'Shaurya Enterprises : Edit User';


            $this->pdf->load_view('mypdfc',$data,$id);

            }

            
            /*$this->loadViews("mypdf", $this->global, $data, NULL);*/
        /*}*/

    }

   



/**
     * This function is used load created lr
     * @param number $userId : Optional : This is user id
     */
    function editexlrc($id = NULL)
    {
        /*if($this->isAdmin() == TRUE || $id == 1)
        {
            $this->loadThis();
        }*/
        /*else
        {
        */    if($id == null)
            {
                redirect('lrListing');
            }
            
            $data['vehicles']=$this->user_model->getvehicles();
            $data['lrinfo'] = $this->lr_model->getlrInfop($id);
            $data['cities']=$this->user_model->getcities();
            $this->global['pageTitle'] = 'Shaurya Enterprises : Edit User';


           
            
            $this->loadViews("editexlr", $this->global, $data, NULL);
        /*}*/
    }













    
    /**
     * This function is used to edit the user information
     */
    function editUser()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $userId = $this->input->post('userId');
            
            $this->form_validation->set_rules('fname','Full Name','trim|required|max_length[128]');
            $this->form_validation->set_rules('email','Email','trim|required|valid_email|max_length[128]');
            $this->form_validation->set_rules('password','Password','matches[cpassword]|max_length[20]');
            $this->form_validation->set_rules('cpassword','Confirm Password','matches[password]|max_length[20]');
            $this->form_validation->set_rules('role','Role','trim|required|numeric');
             $this->form_validation->set_rules('status','Status','trim|required');
            $this->form_validation->set_rules('mobile','Mobile Number','required|min_length[10]');
            
            if($this->form_validation->run() == FALSE)  
            {
                $this->editOld($userId);
            }
            else
            {
                $name = ucwords(strtolower($this->security->xss_clean($this->input->post('fname'))));
                $email = strtolower($this->security->xss_clean($this->input->post('email')));
                $password = $this->input->post('password');
                $roleId = $this->input->post('role');
                $status=$this->security->xss_clean($this->input->post('status'));
                $mobile = $this->security->xss_clean($this->input->post('mobile'));
                
                $userInfo = array();
                
                if(empty($password))
                {
                    $userInfo = array('email'=>$email, 'roleId'=>$roleId, 'name'=>$name,
                                    'mobile'=>$mobile, 'updatedBy'=>$this->vendorId, 'status'=>$status,'updatedDtm'=>date('Y-m-d H:i:s'));
                }
                else
                {
                    $userInfo = array('email'=>$email, 'password'=>getHashedPassword($password), 'roleId'=>$roleId,
                        'name'=>ucwords($name), 'mobile'=>$mobile,'status'=>$status, 'updatedBy'=>$this->vendorId, 
                        'updatedDtm'=>date('Y-m-d H:i:s'));
                }
                
                $result = $this->user_model->editUser($userInfo, $userId);
                
                if($result == true)
                {
                    $this->session->set_flashdata('success', 'User updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'User updation failed');
                }
                
                redirect('userListing');

            }
        }
    }

 /**
     * This function is used to edit the customer information
     */
    function editcust()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }/*ifends here*/

        else /*main else starts here*/
        {
            $this->load->library('form_validation');
            
            $id = $this->input->post('custId');
            
             $this->form_validation->set_rules('cname','Customer Name','trim|required|max_length[500]');
            $this->form_validation->set_rules('address1','Address 1','trim|required|max_length[128]');
            $this->form_validation->set_rules('address2','Address 2','trim|required|max_length[128]');
            $this->form_validation->set_rules('city','City','trim|required|max_length[100]');
            $this->form_validation->set_rules('state','State','trim|required|max_length[100]');
            $this->form_validation->set_rules('pan','PAN','trim|required|max_length[10]|min_length[10]');
            $this->form_validation->set_rules('Email','Email','trim|required|valid_email|max_length[500]');
            $this->form_validation->set_rules('pincode','Pincode','trim|required|numeric|max_length[6]|min_length[6]');
            $this->form_validation->set_rules('GSTNO','GST NO','required|max_length[15]|min_length[15]');
            $this->form_validation->set_rules('cft','CFT','required|numeric|max_length[1000000]');
            $this->form_validation->set_rules('conp','Contact Person','required|max_length[200]');
            $this->form_validation->set_rules('conpn','Contact No','required|max_length[10]');
           if($this->form_validation->run() == FALSE)
            {
                $this->editOldcust($id);
            }
            else /*2nd else strats here*/
            {
                $cname = ucwords(strtolower($this->security->xss_clean($this->input->post('cname'))));
                $address1= $this->input->post('address1');
                $address2= $this->input->post('address2');
                $city= $this->input->post('city');
                $email = strtolower($this->security->xss_clean($this->input->post('Email')));
                $pincode= $this->input->post('pincode');
                $gstno= $this->input->post('GSTNO');
                $cft= $this->input->post('cft');
                $state=$this->input->post('state');
                $pan=$this->input->post('pan');
                $conp=$this->input->post('conp');
                $conpn=$this->input->post('conpn');
                $custtype=$this->input->post('custtype');
                
                 
                $customercheckemail=$this->cust_model->cust_existsmail($email);
                $customercheckuemail=$this->cust_model->cust_existsumail($email);

                $getcustmail=$this->cust_model->cust_mail($id);
                $getcustgstno=$this->cust_model->cust_gstno($id);

                 if($email==$getcustmail) /*3rd if starts here*/
                {
                    if($gstno==$getcustgstno)
                    {

                      $custInfo = array('customername'=>$cname, 'address1'=>$address1, 'address2'=>$address2,
                            'city'=>$city,'state'=>$state,'pan'=>$pan, 'pincode'=>$pincode, 'email'=>$email,'gstno'=>$gstno,'ccft'=>$cft,'contactperson'=>$conp,'contactperson'=>$conp,'conpersonno'=>$conpn,'customertype'=>$custtype);   
                       $result = $this->cust_model->editcust($custInfo, $id);
                       if($result == true)
                             {
                    
                    
                                $this->session->set_flashdata('success', 'Customer updated successfully');
                              }
                        else
                            {
                                $this->session->set_flashdata('error', 'Customer updation failed');
                    
                            }
                        redirect('custListing');

                
                     }
                    

                } /*3rd if ends here*/

                else
                {
                    if($customercheckemail >0)
                    {
                    $this->session->set_flashdata('error', 'Customer already exist with same email');
                    redirect('custListing');

                    }

                    elseif($customercheckuemail >0)
                    {
                    $this->session->set_flashdata('error', 'Email is already taken.');
                    redirect('custListing');

                    }
                    else
                    {

                
                        $custInfo = array('customername'=>$cname, 'address1'=>$address1, 'address2'=>$address2,
                            'city'=>$city,'state'=>$state,'pan'=>$pan, 'pincode'=>$pincode, 'email'=>$email,'gstno'=>$gstno,'ccft'=>$cft,'contactperson'=>$conp,'contactperson'=>$conp,'conpersonno'=>$conpn,'customertype'=>$custtype);
                    }
                
                        $result = $this->cust_model->editcust($custInfo, $id);
                
                     if($result == true)
                    {
                    
                    
                    $this->session->set_flashdata('success', 'Customer updated successfully');
                    }
                    else
                    {
                    $this->session->set_flashdata('error', 'Customer updation failed');
                    
                    }
                    redirect('custListing');



                    
                 }

                
               
                
                
            }/*2nd else closes here*/
        }
    }

    function editcustc()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $id = $this->input->post('custId');
            
             $this->form_validation->set_rules('cname','Customer Name','trim|required|max_length[500]');
            $this->form_validation->set_rules('address1','Address 1','trim|required|max_length[128]');
            $this->form_validation->set_rules('address2','Address 2','trim|required|max_length[128]');
            $this->form_validation->set_rules('city','City','trim|required|max_length[100]');
            $this->form_validation->set_rules('state','State','trim|required|max_length[100]');
            $this->form_validation->set_rules('pan','PAN','trim|required|max_length[10]|min_length[10]');
            $this->form_validation->set_rules('Email','Email','trim|required|valid_email|max_length[500]');
            $this->form_validation->set_rules('pincode','Pincode','trim|required|numeric|max_length[6]|min_length[6]');
            $this->form_validation->set_rules('GSTNO','GST NO','required|max_length[15]|min_length[15]');
            
            $this->form_validation->set_rules('conp','Contact Person','required|max_length[200]');
            $this->form_validation->set_rules('conpn','Contact No','required|max_length[10]');
           if($this->form_validation->run() == FALSE)
            {
                $this->editOldcust($id);
            }
            else
            {
                $cname = ucwords(strtolower($this->security->xss_clean($this->input->post('cname'))));
                $address1= $this->input->post('address1');
                $address2= $this->input->post('address2');
                $city= $this->input->post('city');
                $email = strtolower($this->security->xss_clean($this->input->post('Email')));
                $pincode= $this->input->post('pincode');
                $gstno= $this->input->post('GSTNO');
                $state=$this->input->post('state');
                $pan=$this->input->post('pan');
                $conp=$this->input->post('conp');
                $conpn=$this->input->post('conpn');
                $custtype=$this->input->post('custtype');
                
                 
                $customercheckemail=$this->cust_model->cust_existsmail($email);
                $customercheckuemail=$this->cust_model->cust_existsumail($email);

                $getcustmail=$this->cust_model->cust_mail($id);
                $getcustgstno=$this->cust_model->cust_gstno($id);

                 if($email==$getcustmail)
                {
                    if($gstno==$getcustgstno)
                    {

                      $custInfo = array('customername'=>$cname, 'address1'=>$address1, 'address2'=>$address2,
                            'city'=>$city,'state'=>$state,'pan'=>$pan, 'pincode'=>$pincode, 'email'=>$email,'gstno'=>$gstno,'contactperson'=>$conp,'contactperson'=>$conp,'conpersonno'=>$conpn,'customertype'=>$custtype);   
                       $result = $this->cust_model->editcust($custInfo, $id);
                       if($result == true)
                {
                    
                    
                    $this->session->set_flashdata('success', 'Customer updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Customer updation failed');
                    
                }
                redirect('custListing');

                
                    }
                    

                }
                else
                {
                    if($customercheckemail >0)
                {
                    $this->session->set_flashdata('error', 'Customer already exist with same email');
                    redirect('custListing');

                }
                 elseif($customercheckuemail >0)
                {
                    $this->session->set_flashdata('error', 'Email is already taken.');
                    redirect('custListing');

                }
                else
                {

                
                $custInfo = array('customername'=>$cname, 'address1'=>$address1, 'address2'=>$address2,
                            'city'=>$city,'state'=>$state,'pan'=>$pan, 'pincode'=>$pincode, 'email'=>$email,'gstno'=>$gstno,'ccft'=>$cft,'contactperson'=>$conp,'contactperson'=>$conp,'conpersonno'=>$conpn,'customertype'=>$custtype);
                }
                
                $result = $this->cust_model->editcust($custInfo, $id);
                
                if($result == true)
                {
                    
                    
                    $this->session->set_flashdata('success', 'Customer updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Customer updation failed');
                    
                }
                redirect('custListing');



                    
                }

                
               
                
                
            }
        }
    }


    /**
     * This function is used to delete the user using userId
     * @return boolean $result : TRUE / FALSE
     */
    function deleteUser()
    {
        if($this->isAdmin() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $userId = $this->input->post('userId');
            $userInfo = array('isDeleted'=>1,'updatedBy'=>$this->vendorId, 'updatedDtm'=>date('Y-m-d H:i:s'));
            
            $result = $this->user_model->deleteUser($userId, $userInfo);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }

     function deletefre()
    {
        if($this->isAdmin() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $fid = $this->input->post('fid');
            $freinfo = array('isDeleted'=>1,'updatedBy'=>$this->vendorId, 'updatedDtm'=>date('Y-m-d H:i:s'));
            
            $result = $this->cust_model->deletefre($fid, $freinfo);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }


    function deletecity()
    {
         if($this->isAdmin() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $cid = $this->input->post('cid');
            $cityinfo = array('isDeleted'=>1,'updatedBy'=>$this->vendorId, 'updatedDtm'=>date('Y-m-d H:i:s'));
            
            $result = $this->user_model->deletecity($cid, $cityinfo);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }

    }
    
 /**
     * This function is used to delete the customer using userId
     * @return boolean $result : TRUE / FALSE
     */
    function deletecust()
    {
        if($this->isAdmin() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $custId = $this->input->post('custId');
            /*$getbalance*/
            $custInfo = array('isDeleted'=>1,'updatedBy'=>$this->vendorId, 'updatedDtm'=>date('Y-m-d H:i:s'));
            
            $result = $this->cust_model->deletecust($custId, $custInfo);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }
   





    /**
     * Page not found : error 404
     */
    function pageNotFound()
    {
        $this->global['pageTitle'] = 'Shaurya Enterprises : 404 - Page Not Found';
        
        $this->loadViews("404", $this->global, NULL, NULL);
    }

    /**
     * This function used to show login history
     * @param number $userId : This is user id
     */
    function loginHistoy($userId = NULL)
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $userId = ($userId == NULL ? 0 : $userId);

            $searchText = $this->input->post('searchText');
            $fromDate = $this->input->post('fromDate');
            $toDate = $this->input->post('toDate');

            $data["userInfo"] = $this->user_model->getUserInfoById($userId);

            $data['searchText'] = $searchText;
            $data['fromDate'] = $fromDate;
            $data['toDate'] = $toDate;
            
            $this->load->library('pagination');
            
            $count = $this->user_model->loginHistoryCount($userId, $searchText, $fromDate, $toDate);

            $returns = $this->paginationCompress ( "login-history/".$userId."/", $count, 10, 3);

            $data['userRecords'] = $this->user_model->loginHistory($userId, $searchText, $fromDate, $toDate, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'Shaurya Enterprises : User Login History';
            
            $this->loadViews("loginHistory", $this->global, $data, NULL);
        }        
    }

    /**
     * This function is used to show users profile
     */
    function profile($active = "details")
    {
        $data["userInfo"] = $this->user_model->getUserInfoWithRole($this->vendorId);
        $data["active"] = $active;
        
        $this->global['pageTitle'] = $active == "details" ? 'Shaurya Enterprises : My Profile' : 'Shaurya Enterprises : Change Password';
        $this->loadViews("profile", $this->global, $data, NULL);
    }

    /**
     * This function is used to update the user details
     * @param text $active : This is flag to set the active tab
     */
    function profileUpdate($active = "details")
    {
        $this->load->library('form_validation');
            
        $this->form_validation->set_rules('fname','Full Name','trim|required|max_length[128]');
        $this->form_validation->set_rules('mobile','Mobile Number','required|min_length[10]');
        $this->form_validation->set_rules('email','Email','trim|required|valid_email|max_length[128]|callback_emailExists');        
        
        if($this->form_validation->run() == FALSE)
        {
            $this->profile($active);
        }
        else
        {
            $name = ucwords(strtolower($this->security->xss_clean($this->input->post('fname'))));
            $mobile = $this->security->xss_clean($this->input->post('mobile'));
            $email = strtolower($this->security->xss_clean($this->input->post('email')));
            
            $userInfo = array('name'=>$name, 'email'=>$email, 'mobile'=>$mobile, 'updatedBy'=>$this->vendorId, 'updatedDtm'=>date('Y-m-d H:i:s'));
            
            $result = $this->user_model->editUser($userInfo, $this->vendorId);
            
            if($result == true)
            {
                $this->session->set_userdata('name', $name);
                $this->session->set_flashdata('success', 'Profile updated successfully');
            }
            else
            {
                $this->session->set_flashdata('error', 'Profile updation failed');
            }

            redirect('profile/'.$active);
        }
    }

    /**
     * This function is used to change the password of the user
     * @param text $active : This is flag to set the active tab
     */
    function changePassword($active = "changepass")
    {
        $this->load->library('form_validation');
        
        $this->form_validation->set_rules('oldPassword','Old password','required|max_length[20]');
        $this->form_validation->set_rules('newPassword','New password','required|max_length[20]');
        $this->form_validation->set_rules('cNewPassword','Confirm new password','required|matches[newPassword]|max_length[20]');
        
        if($this->form_validation->run() == FALSE)
        {
            $this->profile($active);
        }
        else
        {
            $oldPassword = $this->input->post('oldPassword');
            $newPassword = $this->input->post('newPassword');
            
            $resultPas = $this->user_model->matchOldPassword($this->vendorId, $oldPassword);
            
            if(empty($resultPas))
            {
                $this->session->set_flashdata('nomatch', 'Your old password is not correct');
                redirect('profile/'.$active);
            }
            else
            {
                $usersData = array('password'=>getHashedPassword($newPassword), 'updatedBy'=>$this->vendorId,
                                'updatedDtm'=>date('Y-m-d H:i:s'));
                
                $result = $this->user_model->changePassword($this->vendorId, $usersData);
                
                if($result > 0) { $this->session->set_flashdata('success', 'Password updation successful'); }
                else { $this->session->set_flashdata('error', 'Password updation failed'); }
                
                redirect('profile/'.$active);
            }
        }
    }

    /**
     * This function is used to check whether email already exist or not
     * @param {string} $email : This is users email
     */
    function emailExists($email)
    {
        $userId = $this->vendorId;
        $return = false;

        if(empty($userId)){
            $result = $this->user_model->checkEmailExists($email);
        } else {
            $result = $this->user_model->checkEmailExists($email, $userId);
        }

        if(empty($result)){ $return = true; }
        else {
            $this->form_validation->set_message('emailExists', 'The {field} already taken');
            $return = false;
        }

        return $return;
    }

/*this funtion is for add customers*/
  function addNewCustomer()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('cname','Customer Name','trim|required|max_length[500]');
            $this->form_validation->set_rules('address1','Address 1','trim|required|max_length[128]');
            $this->form_validation->set_rules('address2','Address 2','trim|required|max_length[128]');
            $this->form_validation->set_rules('city','City','trim|required|max_length[100]');
            $this->form_validation->set_rules('state','State','trim|required|max_length[100]');
            $this->form_validation->set_rules('pan','PAN','trim|required|max_length[10]|min_length[10]');
           
            $this->form_validation->set_rules('Email','Email','trim|required|valid_email');
            $this->form_validation->set_rules('pincode','Pincode','trim|required|numeric|max_length[6]');
            $this->form_validation->set_rules('GSTNO','GST NO','required|max_length[15]');
            $this->form_validation->set_rules('cft','CFT','required|numeric|max_length[100]');
            $this->form_validation->set_rules('conpn','Contact No','required|numeric|max_length[10]');
            $this->form_validation->set_rules('conp','Contact Person','trim|required|max_length[200]');
            $this->form_validation->set_message('check_duplicate_email', 'This customer is alreadyexist. Please write a new email.');
            $this->form_validation->set_rules('custtype','customer type','trim|required|max_length[500]');
            if($this->form_validation->run() == FALSE)
            {
                $this->addNewcust();
            }
            else
            {
                $cname = ucwords(strtolower($this->security->xss_clean($this->input->post('cname'))));
                $address1= $this->input->post('address1');
                $address2= $this->input->post('address2');
                $city= $this->input->post('city');
                $email = strtolower($this->security->xss_clean($this->input->post('Email')));
                $pincode= $this->input->post('pincode');
                $gstno= $this->input->post('GSTNO');
                $cft= $this->input->post('cft');
                $state=$this->input->post('state');
                $pan=$this->input->post('pan');
                $conp=$this->input->post('conp');
                $conpn=$this->input->post('conpn');
                $custtype=$this->input->post('custtype');

                
                $customercheck=$this->cust_model->cust_exists($gstno);
                $customercheckemail=$this->cust_model->cust_existsmail($email);
                $customercheckuemail=$this->cust_model->cust_existsumail($email);

                
                if($customercheckemail >0)
                {
                    $this->session->set_flashdata('error', 'Customer already exist with same email');
                    redirect('ctyper');

                }
                
                elseif($customercheckuemail >0)
                {
                    $this->session->set_flashdata('error', 'Email is already taken.');
                    redirect('ctyper');

                }
                
                
                
                
                
                else{

                if(empty($customercheck))
                {
                   

                    

                $CustomerInfo = array('customername'=>$cname, 'address1'=>$address1, 'address2'=>$address2, 'city'=> $city,'state'=>$state,'pan'=>$pan,'pincode'=>$pincode, 'email'=>$email, 'gstno'=>$gstno,'ccft'=>$cft,'contactperson'=>$conp,'conpersonno'=>$conpn,'customertype'=>$custtype);

                $this->load->model('cust_model');
                $result = $this->cust_model->addNewUser($CustomerInfo);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'New Customer added successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Customer creation failed');
                }
                
                redirect('custListing');
                
                }

                else
                {
                 $this->session->set_flashdata('error', 'Customer already exist');
                 redirect('custListing');

                }

            }

            
            }
        }
    }



    function vehicle()
    {

        $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->user_model->vehicleListingCount($searchText);

            $returns = $this->paginationCompress ( "vehicle/", $count, 10 );
            
            $data['vehicleRecords'] = $this->user_model->vehicleListing($searchText, $returns["page"], $returns["segment"]);

              $this->global['pageTitle'] = 'Shaurya Enterprises : Vehicle Master';
              $this->loadViews("vehicle", $this->global, $data, NULL);
            
            
    }
    function  editvehicle($id=null)
    {
         if($id==null)
        {
            $this->city();
        }
        elseif($id==0)
        {
            $this->city();
        }
        elseif(empty($id))
        {
         $this->city();   
        }
        else{
        $data['vehicles']=$this->user_model->getvehiclebyid($id);
        
         $this->global['pageTitle'] = 'Shaurya Enterprises : Vehicle Master';
         $this->loadViews("editvehicle", $this->global, $data, NULL);
         }

    }

    function  updatevehicle($id=null)
    {

        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        if($id==0)
        {
            $this->vehicle();
        }
        else
        {
            $this->load->library('form_validation');

            $this->form_validation->set_rules('vehiclename','vehicle details','trim|required|max_length[100]');

            if($this->form_validation->run() == FALSE)
            {
                $this->vehicle();
            }
            else
            {
                    $vehiclename = ucwords(strtolower($this->security->xss_clean($this->input->post('vehiclename'))));

                     $updatevehicle=array("name"=>$vehiclename,"isDeleted"=>0);
                    $result = $this->user_model->updatevehicle($updatevehicle,$id);

                     if($result > 0)
                {
                    $this->session->set_flashdata('success', 'Vehicle Updated successfully.');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Failed to Update vehicle');
                }
                
                redirect('vehicle');
            }
        }

    }

    function deleteVehicle()
    {
        if($this->isAdmin() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $vid = $this->input->post('vid');
            $vehicleinfo = array('isDeleted'=>1,'updatedBy'=>$this->vendorId, 'updatedDtm'=>date('Y-m-d H:i:s'));
            
            $result = $this->user_model->deletevehicle($vid, $vehicleinfo);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }

    }




    function city()
    {

        $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->user_model->cityListingCount($searchText);

            $returns = $this->paginationCompress ( "city/", $count, 10 );
            
            $data['cityRecords'] = $this->user_model->cityListing($searchText, $returns["page"], $returns["segment"]);

              $this->global['pageTitle'] = 'Shaurya Enterprises : City Master';
              $this->loadViews("cities", $this->global, $data, NULL);
            
            
    }
    function cinfoform()
    {
        $data['compinfo']=$this->user_model->getcompinfo();

        if(!empty($data['compinfo']))
        {
            $this->global['pageTitle'] = 'Shaurya Enterprises : Company Profile';
        $this->loadViews("updatecomprofile", $this->global, $data, NULL);

        }
        else
        {
        $this->global['pageTitle'] = 'Shaurya Enterprises : Company Profile';
        $this->loadViews("compprofile", $this->global, null, NULL);

        }


    }

    function addcompany()
    {

        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('compname','Company Name','trim|required|max_length[500]');
            $this->form_validation->set_rules('compadd',' Company Address','trim|required|max_length[128]');
            $this->form_validation->set_rules('compemail','Email','trim|required|max_length[128]');
            $this->form_validation->set_rules('mobile','mobile','trim|required|max_length[100]');
            $this->form_validation->set_rules('GSTNO','State','trim|required|max_length[100]');
            $this->form_validation->set_rules('pan','PAN','trim|required|max_length[10]|min_length[10]');
            $this->form_validation->set_rules('subjecto','subjec to','trim|required');
            $this->form_validation->set_rules('bankname','Bank name','trim|required');
            $this->form_validation->set_rules('acno','Account no','trim|required');
            $this->form_validation->set_rules('ifsc','IFSC code','trim|required');
            $this->form_validation->set_rules('branch','branch','trim|required');
            

            

            if($this->form_validation->run() == FALSE)
            {
                $this->cinfoform();
            }

            else
            {
                $companyname= $this->input->post('compname');
                $companyadd= $this->input->post('compadd');
                $companymail= $this->input->post('compemail');
                $companymobile= $this->input->post('mobile');
                $companygstno= $this->input->post('GSTNO');
                $companypan= $this->input->post('pan');
                $subjecto= $this->input->post('subjecto');
                $bankname= $this->input->post('bankname');
                $acno= $this->input->post('acno');
                $ifsc= $this->input->post('ifsc');
                $branch= $this->input->post('branch');

                $companyinfo=array('compname'=>$companyname,'compadd'=>$companyadd,'compemail'=>$companymail,
                                    'compmobile'=>$companymobile,'compGSTNO'=>$companygstno,'comppan'=>$companypan,
                                    'compsubjecto'=>$subjecto,'compbankname'=>$bankname,'compacno'=>$acno,
                                    'ifsc'=>$ifsc,'branch'=>$branch
                                   );
                $result=$this->user_model->addcomp($companyinfo);
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'Company Profile added successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Failed to add company profile');
                }
                
                redirect('companyinfo');





            }
        }
           
         

    }
    function updatecompany()
    {

        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('compname','Company Name','trim|required|max_length[500]');
            $this->form_validation->set_rules('compadd',' Company Address','trim|required|max_length[128]');
            $this->form_validation->set_rules('compemail','Email','trim|required|max_length[128]');
            $this->form_validation->set_rules('mobile','mobile','trim|required|max_length[100]');
            $this->form_validation->set_rules('GSTNO','State','trim|required|max_length[100]');
            $this->form_validation->set_rules('pan','PAN','trim|required|max_length[10]|min_length[10]');
            $this->form_validation->set_rules('subjecto','subjec to','trim|required');
            $this->form_validation->set_rules('bankname','Bank name','trim|required');
            $this->form_validation->set_rules('acno','Account no','trim|required');
            $this->form_validation->set_rules('ifsc','IFSC code','trim|required');
            $this->form_validation->set_rules('branch','branch','trim|required');
            $this->form_validation->set_rules('cid','cid','trim|required');
            

            

            if($this->form_validation->run() == FALSE)
            {
                $this->cinfoform();
            }

            else
            {
                $companyname= $this->input->post('compname');
                $companyadd= $this->input->post('compadd');
                $companymail= $this->input->post('compemail');
                $companymobile= $this->input->post('mobile');
                $companygstno= $this->input->post('GSTNO');
                $companypan= $this->input->post('pan');
                $subjecto= $this->input->post('subjecto');
                $bankname= $this->input->post('bankname');
                $acno= $this->input->post('acno');
                $ifsc= $this->input->post('ifsc');
                $branch= $this->input->post('branch');
                $id=$this->input->post('cid');

                $companyinfo=array('compname'=>$companyname,'compadd'=>$companyadd,'compemail'=>$companymail,
                                    'compmobile'=>$companymobile,'compGSTNO'=>$companygstno,'comppan'=>$companypan,
                                    'compsubjecto'=>$subjecto,'compbankname'=>$bankname,'compacno'=>$acno,
                                    'ifsc'=>$ifsc,'branch'=>$branch
                                   );
                $result=$this->user_model->updatecomp($companyinfo,$id);
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'Company Profile updated successfully');
                }
                else
                {
                     $this->session->set_flashdata('success', 'Company Profile is already Up to date');
                }
                
                redirect('companyinfo');





            }
        }
           
         

    }


    function addnewcity()
    {
           $this->global['pageTitle'] = 'Shaurya Enterprises : City Master';
         $this->loadViews("addnewcity", $this->global, null, NULL);

    }
    function addnewvehicle()
    {
          $this->global['pageTitle'] = 'Shaurya Enterprises : City Master';
         $this->loadViews("addnewvehicle", $this->global, null, NULL);


    }
    function addvehicle()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');

            $this->form_validation->set_rules('vehiclename','Vehicle Name','trim|required|max_length[100]');

            if($this->form_validation->run() == FALSE)
            {
                $this->addnewvehicle();
            }
            else
            {

            $vname = ucwords(strtolower($this->security->xss_clean($this->input->post('vehiclename'))));

            $checkvehicles = $this->user_model->checkvehicles($vname);
            if($checkvehicles >0)
            {
                $this->session->set_flashdata('error', 'vehicle record already  exist');
                redirect('vehicle');

            }
            else
            {


            
            $addvehicle=array("name"=>$vname,"isDeleted"=>0);
            $result = $this->user_model->addnvehicle($addvehicle);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'New vehicle successfully Added');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Failed to add new vehicle');
                }
                
                redirect('vehicle');
            }

             }
        }

    }

    function addcity()
    {
         if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');

            $this->form_validation->set_rules('cityname','City Name','trim|required|max_length[100]');

            if($this->form_validation->run() == FALSE)
            {
                $this->addnewcity();
            }
            else
            {

            $cityname = ucwords(strtolower($this->security->xss_clean($this->input->post('cityname'))));

            $checkcity=$this->user_model->checkcity($cityname);
            if($checkcity >0)
            {
                $this->session->set_flashdata('error', 'City record already exist');

            redirect('city');
           
            }
            else
            {
                 $addcity=array("cities"=>$cityname,"isDeleted"=>0);
            $result = $this->user_model->addnewcity($addcity);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'New City successfully Added');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Failed to add new City');
                }
                
                redirect('city');
            }

             }
        }


    }
    
    function editcity($id=null)

    {
        if($id==null)
        {
            $this->city();
        }
        elseif($id==0)
        {
            $this->city();
        }
        elseif(empty($id))
        {
         $this->city();   
        }
        else{
        $data['cities']=$this->user_model->getcitiesbyid($id);
        
         $this->global['pageTitle'] = 'Shaurya Enterprises : City Master';
         $this->loadViews("editcity", $this->global, $data, NULL);
         }

    }







    function updatecity($id=null)
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        if($id==0)
        {
            $this->city();
        }
        else
        {
            $this->load->library('form_validation');

            $this->form_validation->set_rules('cityname','City Name','trim|required|max_length[100]');

            if($this->form_validation->run() == FALSE)
            {
                $this->addnewcity();
            }
            else
            {
                    $cityname = ucwords(strtolower($this->security->xss_clean($this->input->post('cityname'))));

                     $addcity=array("cities"=>$cityname,"isDeleted"=>0);
                    $result = $this->user_model->updatecity($addcity,$id);

                     if($result > 0)
                {
                    $this->session->set_flashdata('success', 'City Updated successfully.');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Failed to Update City');
                }
                
                redirect('city');
            }
        }

    }

    function ctype()
    {
        $this->global['pageTitle'] = 'Shaurya Enterprises : Customer management';
         $this->loadViews("addnewrcust", $this->global, null, NULL);

    }

    function ctypec()
    {
        $data['cities']=$this->user_model->getcities();
        $data['vehicles']=$this->user_model->getvehicles();
        $this->global['pageTitle'] = 'Shaurya Enterprises :Customer management';
         $this->loadViews("addnewccust", $this->global, $data, NULL);

    }

    function addnewcustomerc()
    { 
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('cname','Customer Name','trim|required|max_length[500]');
            $this->form_validation->set_rules('address1','Address 1','trim|required|max_length[128]');
            $this->form_validation->set_rules('address2','Address 2','trim|required|max_length[128]');
            $this->form_validation->set_rules('city','city','trim|required|max_length[100]');
            $this->form_validation->set_rules('fromcity[]','from city','trim|required|max_length[100]');
            $this->form_validation->set_rules('tocity[]','to city','trim|required|max_length[100]');
            $this->form_validation->set_rules('state','State','trim|required|max_length[100]');
            $this->form_validation->set_rules('pan','PAN','trim|required|max_length[10]|min_length[10]');
           
            $this->form_validation->set_rules('Email','Email','trim|required|valid_email');
            $this->form_validation->set_rules('pincode','Pincode','trim|required|numeric|max_length[6]');
            $this->form_validation->set_rules('GSTNO','GST NO','required|max_length[15]');
            $this->form_validation->set_rules('cft[]','CFT','required|numeric|max_length[100]');
            $this->form_validation->set_rules('conpn','Contact No','required|numeric|max_length[10]');
            $this->form_validation->set_rules('conp','Contact Person','trim|required|max_length[200]');
            $this->form_validation->set_message('check_duplicate_email', 'This customer is alreadyexist. Please write a new email.');
            $this->form_validation->set_rules('custtype','customer type','trim|required|max_length[500]');
            if($this->form_validation->run() == FALSE)
            {
                $this->ctypec();
            }
            else
            {
               $cname = ucwords(strtolower($this->security->xss_clean($this->input->post('cname'))));
                $address1= $this->input->post('address1');
                $address2= $this->input->post('address2');
                $city= $this->input->post('city');
                $email = strtolower($this->security->xss_clean($this->input->post('Email')));
                $pincode= $this->input->post('pincode');
                $gstno= $this->input->post('GSTNO');
                
                $state=$this->input->post('state');
                $pan=$this->input->post('pan');
                $conp=$this->input->post('conp');
                $conpn=$this->input->post('conpn');

                
                $vehicle=$this->input->post('vehicle');
                $fromcity= $this->input->post('fromcity');
                $tocity= $this->input->post('tocity');
                $cft= $this->input->post('cft');
                $cftcount= count($this->input->post('cft'));
                $custtype=$this->input->post('custtype');
                
                $customercheck=$this->cust_model->cust_exists($gstno);
                $customercheckemail=$this->cust_model->cust_existsmail($email);
                $customercheckuemail=$this->cust_model->cust_existsumail($email);

                
                if($customercheckemail >0)
                {
                    $this->session->set_flashdata('error', 'Customer already exist with same email');
                    redirect('ctypec');

                }
                
                elseif($customercheckuemail >0)
                {
                    $this->session->set_flashdata('error', 'Email is already taken.');
                    redirect('ctypec');

                }
                
                
                
                
                
                else{

                if(empty($customercheck))
                {
                   

                    

                $CustomerInfo = array('customername'=>$cname, 'address1'=>$address1, 'address2'=>$address2, 'city'=> $city,'state'=>$state,'pan'=>$pan,'pincode'=>$pincode, 'email'=>$email, 'gstno'=>$gstno,'contactperson'=>$conp,'conpersonno'=>$conpn,'customertype'=>$custtype);

                $this->load->model('cust_model');
                $result = $this->cust_model->addNewUser($CustomerInfo);
                
                if($result > 0)
                {
                    for($i=0;$i<$cftcount;$i++)
                    {


                    $freightdata=array('vehicle'=>$vehicle[$i],'fromc'=>$fromcity[$i],'toc'=>$tocity[$i],'freightrate'=>$cft[$i],'custid'=>$result);


                    $freightresult = $this->cust_model->addfreight($freightdata);
                }
                    if($freightresult >0)
                    {

                    $this->session->set_flashdata('success', 'New Customer added successfully');
                     }
                
                else
                {
                    $this->session->set_flashdata('error', 'Customer creation failed');
                }
                }
                
                redirect('custListing');
                
                }

                else
                {
                 $this->session->set_flashdata('error', 'Customer already exist');
                 redirect('ctypec');

                }

            } 
            }
    }
}

function editfreight($id=null)
{

    if($id==0)
    {
    $this->session->set_flashdata('error', 'No record(s) found.');
    redirect('custListing');
    }
    else
    {   
        $data['custdata']=$id;
        $data['freightdata']=$this->cust_model->getfreight($id);
         $data['cities']=$this->user_model->getcities();
        $data['vehicles']=$this->user_model->getvehicles();

    $this->global['pageTitle'] = 'Shaurya Enterprises :Freight';
    $this->loadViews("freight", $this->global, $data, NULL);
    }


}

function editfrerec($id=null)
{
    if($id==0)
    {
    $this->session->set_flashdata('error', 'No record(s) found.');
    redirect($_SERVER['HTTP_REFERER']);

     
    }

    $data['freightdata']=$this->cust_model->getfreightrec($id);
    $data['cities']=$this->user_model->getcities();
    $data['vehicles']=$this->user_model->getvehicles();

     $this->global['pageTitle'] = 'Shaurya Enterprises :Freight';
    $this->loadViews("editfrerec", $this->global, $data, NULL);



    




}

function updatefreight()
{
    $this->load->library('form_validation');
            
            $this->form_validation->set_rules('vehicle','vehicle type','trim|required|max_length[500]');
            $this->form_validation->set_rules('fromcity','from','trim|required|max_length[128]');
            $this->form_validation->set_rules('tocity','to','trim|required|max_length[128]');
            $this->form_validation->set_rules('cft','freight','trim|required|max_length[100]');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->editfrerec($id);
            }
            $id=$this->input->post('id');
            $vehicle=$this->input->post('vehicle');
            $fromcity=$this->input->post('fromcity');
            $tocity=$this->input->post('tocity');
            $cft=$this->input->post('cft');

            $updatefret=array('vehicle'=>$vehicle,'fromc'=>$fromcity,'toc'=>$tocity,'freightrate'=>$cft);

            $update=$this->cust_model->updatefreight($id,$updatefret);
            if($update >0)
            {
                 $this->session->set_flashdata('success', 'freight updated successfully');
                 $this->editfrerec($id);

            }
            elseif($update == 0)
            {
                $this->session->set_flashdata('error', 'details alredy updated');
                 $this->editfrerec($id);

            }
            else
            {
                $this->session->set_flashdata('error', 'freight updation failed');
                 $this->editfrerec($id);

            }





}

/*addfreightstarts here*/
function addfreight()
    { 
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('fromcity[]','from city','trim|required|max_length[100]');
            $this->form_validation->set_rules('tocity[]','to city','trim|required|max_length[100]');
            $this->form_validation->set_rules('cft[]','CFT','required|max_length[100]');
            $this->form_validation->set_rules('vehicle[]','CFT','required|max_length[100]');
            if($this->form_validation->run() == FALSE)
            {
                $this->ctypec();
            }
            else
            { 
                $vehicle=$this->input->post('vehicle');
                $fromcity= $this->input->post('fromcity');
                $tocity= $this->input->post('tocity');
                $cft= $this->input->post('cft');
                $cftcount= count($this->input->post('cft'));
                $custid=$this->input->post('custid');

                
                $getfreightdetails=$this->cust_model->getfreightdetails($vehicle,$fromcity,$tocity,$custid);

                if($getfreightdetails >0)
                {
                    $this->session->set_flashdata('error', 'Freight already exist.');
                    
                    $this->editfreight($custid);

                }
                else
                {


                $this->load->model('cust_model');
               
                for($i=0;$i<$cftcount;$i++)
                    {


                    $freightdata=array('vehicle'=>$vehicle[$i],'fromc'=>$fromcity[$i],'toc'=>$tocity[$i],'freightrate'=>$cft[$i],'custid'=>$custid);


                    $freightresult = $this->cust_model->addfreight($freightdata);
                    }

                    if($freightresult >0)
                    {

                    $this->session->set_flashdata('success', 'Freight details added successfully');
                     }
                
                else
                {
                    $this->session->set_flashdata('error', 'failed to add Freight');
                }

                $this->editfreight($custid);

                }

        

                }
                
                
                
                
            } 
            }
    

/*addfreightendshere*/









}
?>