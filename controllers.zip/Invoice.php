<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';
require_once APPPATH . '/libraries/Pdf.php';
class Invoice extends BaseController
{
	public function __construct()
    {
        parent::__construct();
        $this->load->model('user_model');
        $this->load->model('cust_model');
        $this->load->model('lr_model');
        $this->load->model('invoice_model');
        $this->load->library('pdf');
        $this->isLoggedIn();   
        $this->session->keep_flashdata('message');
        
    }

    public function index()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->global['pageTitle'] = 'Shaurya Enterprises : LR Generation';
            $this->loadViews("createinvoice", $this->global, NULL , NULL);
        }

    }

    public function lrListing()
    {
        /*if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }*/
        /*else
        {        
        */    $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->lr_model->lrListingCount($searchText);

            $returns = $this->paginationCompress ( "lrListing/", $count, 10 );
            
            $data['lrRecords'] = $this->lr_model->lrListingforinvoice($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'Shaurya Enterprises : User Listing';
            
            $this->loadViews("createinvoice", $this->global, $data, NULL);
            /*}*/
    }

        public function lrListinginv()
        {
        /*if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }*/
        /*else
        {        
        */    $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->lr_model->lrListingCount($searchText);

            $returns = $this->paginationCompress ( "lrListing/", $count, 10 );
            
            $data['lrRecords'] = $this->lr_model->lrListingforinvoice($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'Shaurya Enterprises : User Listing';
            
            /*$this->loadViews("createinvoice", $this->global, $data, NULL);*/
            /*}*/
        }



        function getlrinfo()

        {
           $cust = $this->input->post('customer');
           if(empty($cust))
           {
            $this->session->set_flashdata('error','Please select customer');
            redirect('createinvoice');

           }
           $data['lrinfo'] = $this->lr_model->getLr($cust);
           $searchText = $this->security->xss_clean($this->input->post('searchText'));
           $data['searchText'] = $searchText;

           $this->load->library('pagination');

           $count = $this->lr_model->lrListingCount($searchText);

           $returns = $this->paginationCompress ( "lrListing/", $count, 10 );

           $data['lrRecords'] = $this->lr_model->lrListingforinvoice($searchText, $returns["page"], $returns["segment"]);

           $this->global['pageTitle'] = 'Shaurya Enterprises : Edit User';
           $this->loadViews("createinvoice", $this->global, $data, NULL);

       }

       function getselectedlr()
       {
            $lrno = $this->input->post('selectedlr');
            $getcustid=$this->lr_model->getcustid($lrno);
            $getcusttype=$this->lr_model->getcusttype($getcustid);


            $lrcount=count($this->input->post('selectedlr'));
             if(empty($lrno))
            {
            $this->session->set_flashdata('error', 'Please select LR');
            redirect('createinvoice');

             }

             else
             {  
                if($getcusttype=='Contract')
                {
                    $getvtype=$this->lr_model->getvtype($lrno);
                 for($i=0;$i<$lrcount;$i++)
                {
              $getvtype=$this->lr_model->getvtype($lrno[$i]);
                
                $getfromcity=$this->lr_model->getfromcity($lrno[$i]);
                $gettocity=$this->lr_model->gettocity($lrno[$i]);
                $gf= json_encode($this->lr_model->getfreight($getcustid,$getfromcity,$gettocity,$getvtype));
                $gff=json_decode($gf,true);
                $g=$gff["freightrate"];

                $cft=array("confreight"=>$g);
                $insf=$this->lr_model->insf($lrno[$i],$cft);

                }
                 $data['lrRecords'] = $this->lr_model->getselectedlrInfo($lrno);
                $data['sac'] = $this->lr_model->getsaccode();
                $data['ids']=$this->invoice_model->getinvoiceid();
                $this->global['pageTitle'] = 'Shaurya Enterprises : Edit User';
                $this->loadViews("invoicemgmtc", $this->global, $data, NULL);

                }


                elseif($getcusttype=='Regular')
                {
                    $data['lrRecords'] = $this->lr_model->getselectedlrInfo($lrno);
                $data['sac'] = $this->lr_model->getsaccode();
                $data['ids']=$this->invoice_model->getinvoiceid();
                $this->global['pageTitle'] = 'Shaurya Enterprises : Edit User';
                $this->loadViews("invoicemgmt", $this->global, $data, NULL);

                }

                else
                {
                    $this->session->set_flashdata('error', 'Invalid Customer Type');
                    redirect('createinvoice');


                }
                
                
                

              

                
               
         }

    }

    

    function addnewinvoice()
    {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('lrtotal','lrtotal','numeric|max_length[100]');
        $this->form_validation->set_rules('lrcharges','lrcharge','numeric|max_length[100]');
        $this->form_validation->set_rules('tax','tax','numeric|max_length[100]');
        $this->form_validation->set_rules('lu','lu','numeric|max_length[100]');
        
        if($this->form_validation->run() == FALSE)
        {
            $this->lrListing();
        }
        else
        {

         $invoicedata = $this->input->post();
         $lrno=$this->input->post('lrno');
         $lrcount=count($lrno);

         $lrtotal=array_sum($invoicedata['lrtotal']);
         $lrcharges=$lrcount*$invoicedata['lrcharges'];

         $lrgst=$invoicedata['tax'];

         $lrlucharges=$invoicedata['lu'];

         $lrsubtotal=$lrtotal+$lrcharges;

         $gst=($lrsubtotal*$lrgst)/100;
         $lrgrandtotal=$lrsubtotal+$gst+$lrlucharges;

         $date=strtotime(date('Y-m-d'));
         $DueDate = date('Y-m-d',strtotime('+15 days',$date));


       
         
         

         $invdata=array('date'=>date('Y-m-d H:i:s'),'lrcharges'=>$lrcharges,'subtotal'=>$lrsubtotal,'gst'=>$lrgst,'total'=>$lrgrandtotal,

            'balancedue'=>$lrgrandtotal,'lrunit'=>$lrcount,'lu'=>$lrlucharges,'gstvalue'=>$gst,'duedate'=>$DueDate
            );


         $invoiceid=$this->invoice_model->saveinvoice($invdata);

         $setinvoice=array('invid'=>$invoiceid);

         $setlrinvid=$this->lr_model->insertinvoiceid($setinvoice,$lrno);

         $setpaymentinvid=$this->invoice_model->insertinvoiceid($setinvoice);

         if($invoiceid > 0)
         {
            $this->session->set_flashdata('success', 'Invoice created successfully');
         }
        
        else
        {
            $this->session->set_flashdata('error', 'Invoice creation failed');
        }

        redirect('createinvoice');






         


        
        }
    }


function getinvoiceinfo()
{
    $data['invoiceinfo']= $this->invoice_model->getinvoiceinfo();

    $this->global['pageTitle'] = 'Shaurya Enterprises : User Listing';

    $this->loadViews("invoicedashboard", $this->global, $data, NULL);

}

function invoiceListing()
{
        /*if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }*/
        /*else
        {        
        */    $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->invoice_model->invListingCount($searchText);

            $returns = $this->paginationCompress ( "viewinvoice/", $count, 10 );
            
            $data['invRecords'] = $this->invoice_model->invListing($searchText, $returns["page"], $returns["segment"]);

            $this->global['pageTitle'] = 'Shaurya Enterprises : Invoices';
            
            $this->loadViews("invoicedashboard", $this->global, $data, NULL);
            /*}*/
        }
        function pdf_gen(){

            /*$this->load->library('pdf');*/

            $filename = time()."_order.pdf";
            $data["hello"]='';
            $html = $this->load->view('bill',$data,true);

// unpaid_voucher is unpaid_voucher.php file in view directory and $data variable has infor mation that you want to render on view.

            $this->load->library('M_pdf');
            $this->m_pdf->pdf->AddPage('L', '', '', '', '', 8, 8, 8, 8, 8, 8);

            $this->m_pdf->pdf->WriteHTML($html);

//download it D save F.

            $this->m_pdf->pdf->Output("./uploads/".$filename, "I"); 

        }



/**
     * This function is used to print invoice
     * @param number $userId : Optional : This is user id
     */
function printinvoice($id = NULL,$custid=Null)
{
        /*if($this->isAdmin() == TRUE || $id == 1)
        {
            $this->loadThis();
        }*/
        /*else
        {
        */    if($id == null & $custid ==null)
            {
                redirect('viewinvoice');
            }
            elseif($id == 0 & $custid ==0)
            {
               redirect('viewinvoice');     
            }

            $getcusttype=$this->lr_model->getcusttype($custid);
            

            if($getcusttype=="Regular")
            {

            $data['invinfo'] = $this->invoice_model->getinvoicebyid($id);
            $data['singleinvinfo'] = $this->invoice_model->getsinvoicebyid($id);
            $data['invoiceto'] = $this->invoice_model->getinvoiceto($id);
            $data['compinfo']=$this->user_model->getcompinfo();

           
            
            $this->global['pageTitle'] = 'Shaurya Enterprises : Edit User';


            $filename = $id.".pdf";
            
            
            $html = $this->load->view('invoicep',$data,true);
            $htmld = $this->load->view('invoicep',$data,true);



            $this->load->library('M_pdf');
            
            
            $this->m_pdf->pdf->WriteHTML($html);

           $this->m_pdf->pdf->AddPage('P', '', '', '', '', 15, 15, 16, 16, 9, 9);
           $this->m_pdf->pdf->SetWatermarkText('Duplicate');
            $this->m_pdf->pdf->showWatermarkText = true;

            
             $this->m_pdf->pdf->WriteHTML($htmld);
             $this->m_pdf->pdf->AddPage('P', '', '', '', '', 15, 15, 16, 16, 9, 9);
            
             $this->m_pdf->pdf->WriteHTML($htmld);
             $this->m_pdf->pdf->SetWatermarkText('Duplicate');
            $this->m_pdf->pdf->showWatermarkText = true;


            $this->m_pdf->pdf->Output("./uploads/".$filename, "I"); 
        }

        elseif($getcusttype =="Contract")
        {
            $data['invinfo'] = $this->invoice_model->getinvoicebyid($id);
            $data['singleinvinfo'] = $this->invoice_model->getsinvoicebyid($id);
            $data['invoiceto'] = $this->invoice_model->getinvoiceto($id);
            $data['compinfo']=$this->user_model->getcompinfo();

           
            
            $this->global['pageTitle'] = 'Shaurya Enterprises : Edit User';


            $filename = $id.".pdf";
            
            
            $html = $this->load->view('invoicepc',$data,true);
            $htmld = $this->load->view('invoicepc',$data,true);



            $this->load->library('M_pdf');
            
            
            $this->m_pdf->pdf->WriteHTML($html);

           $this->m_pdf->pdf->AddPage('P', '', '', '', '', 15, 15, 16, 16, 9, 9);
           $this->m_pdf->pdf->SetWatermarkText('Duplicate');
            $this->m_pdf->pdf->showWatermarkText = true;

            
             $this->m_pdf->pdf->WriteHTML($htmld);
             $this->m_pdf->pdf->AddPage('P', '', '', '', '', 15, 15, 16, 16, 9, 9);
            
             $this->m_pdf->pdf->WriteHTML($htmld);
             $this->m_pdf->pdf->SetWatermarkText('Duplicate');
            $this->m_pdf->pdf->showWatermarkText = true;


            $this->m_pdf->pdf->Output("./uploads/".$filename, "I"); 


        }
        else{
                $this->session->set_flashdata('error', 'Customer details not found');

                redirect('viewinvoice');
            }

            
            /*$this->loadViews("mypdf", $this->global, $data, NULL);*/
            /*}*/
        }


        function downloadinvoice($id = NULL,$custid=Null)
{
        /*if($this->isAdmin() == TRUE || $id == 1)
        {
            $this->loadThis();
        }*/
        /*else
        {
        */    if($id == null & $custid ==null)
            {
                redirect('viewinvoice');
            }
            elseif($id == 0 & $custid ==0)
            {
               redirect('viewinvoice');     
            }

            $getcusttype=$this->lr_model->getcusttype($custid);
            

            if($getcusttype=="Regular")
            {

            $data['invinfo'] = $this->invoice_model->getinvoicebyid($id);
            $data['singleinvinfo'] = $this->invoice_model->getsinvoicebyid($id);
            $data['invoiceto'] = $this->invoice_model->getinvoiceto($id);
            $data['compinfo']=$this->user_model->getcompinfo();

           
            
            $this->global['pageTitle'] = 'Shaurya Enterprises : Edit User';


            $filename = $id.".pdf";
            
            
            $html = $this->load->view('invoicep',$data,true);
            



            $this->load->library('M_pdf');
            
            
            $this->m_pdf->pdf->WriteHTML($html);

           


            $this->m_pdf->pdf->Output('uploads/SE-'.$filename, "F"); 
        }

        elseif($getcusttype =="Contract")
        {
            $data['invinfo'] = $this->invoice_model->getinvoicebyid($id);
            $data['singleinvinfo'] = $this->invoice_model->getsinvoicebyid($id);
            $data['invoiceto'] = $this->invoice_model->getinvoiceto($id);
            $data['compinfo']=$this->user_model->getcompinfo();

           
            
            $this->global['pageTitle'] = 'Shaurya Enterprises : Edit User';


            $filename = $id.".pdf";
            
            
            $html = $this->load->view('invoicepc',$data,true);
            



            $this->load->library('M_pdf');
            
            
            $this->m_pdf->pdf->WriteHTML($html);

           


            $this->m_pdf->pdf->Output('uploads/SE-'.$filename, "F"); 


        }
        else{
                $this->session->set_flashdata('error', 'Customer details not found');

                redirect('viewinvoice');
            }

            
            /*$this->loadViews("mypdf", $this->global, $data, NULL);*/
            /*}*/
        }



    /**
     * This function is used to delete the LR using Lrno
     * @return boolean $result : TRUE / FALSE
     */
    function deleteinv()
    {   
        if($this->isAdmin() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $invno = $this->input->post('invid');
            $checkbalancedue=$this->invoice_model->getbalancedue($invno);
            if($checkbalancedue >0)
            {
               echo(json_encode(array('status'=>FALSE))); 
            }
            else
            {



            $invInfo = array('isDeleted'=>1,'updatedBy'=>$this->vendorId, 'updatedDtm'=>date('Y-m-d H:i:s'));
            $invidInfo = array('invid'=>NULL);
            $result = $this->invoice_model->deleteinv($invno,$invInfo);
            $updatelr=$this->invoice_model->setinvid($invno,$invidInfo);
            
            if ($result>0 and $updatelr>0) 
            {
               echo(json_encode(array('status'=>TRUE))); 
           }

           else {
                 echo(json_encode(array('status'=>FALSE))); 
                }

        }
    }
    }
    

function editinvoice($id = NULL)
{
        /*if($this->isAdmin() == TRUE || $id == 1)
        {
            $this->loadThis();
        }*/
        /*else
        {
        */



            if($id == null)
            {
                redirect('viewinvoice');
            }
            

            $data['invinfo'] = $this->invoice_model->getsinvoicebyid($id);
            
            $this->global['pageTitle'] = 'Shaurya Enterprises : Edit User';


            $data['lrRecords'] = $this->lr_model->getselectedlrInfoinv($id);
            $data['sac']= $this->lr_model->getsaccode();
            
            $this->loadViews("editinv", $this->global, $data, NULL);
            /*}*/
        }



        function updateinvoice()
        {

            $this->load->library('form_validation');
            $this->form_validation->set_rules('lrtotal','lrtotal','numeric|max_length[100]');
            $this->form_validation->set_rules('lrcharges','lrcharge','numeric|max_length[100]');
            $this->form_validation->set_rules('tax','tax','numeric|max_length[100]');
            $this->form_validation->set_rules('lu','lu','numeric|max_length[100]');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->lrListing();
            }
            else
            {

             $invoicedata = $this->input->post();
             $lrno=$invoicedata['lrno'];
             $invid=$invoicedata['invid'];
             $lrcount=count($lrno);

             $lrtotal=array_sum($invoicedata['lrtotal']);

             $lrcharges=$lrcount*$invoicedata['lrcharges'];

             $lrgst=$invoicedata['tax'];

             $lrlucharges=$invoicedata['lu'];

             $lrsubtotal=$lrtotal+$lrcharges;

             $gst=($lrsubtotal*$lrgst)/100;
             $lrgrandtotal=$lrsubtotal+$gst+$lrlucharges;


            

             $invdata=array('date'=>date('Y-m-d H:i:s'),'lrcharges'=>$lrcharges,'subtotal'=>$lrsubtotal,'gst'=>$lrgst,'total'=>$lrgrandtotal,

                'balancedue'=>$lrgrandtotal,'lrunit'=>$lrcount,'lu'=>$lrlucharges,'gstvalue'=>$gst
                );


             $invoiceid=$this->invoice_model->updateinvoice($invdata,$invid);
             



             $setinvoice=array('invid'=>$invoiceid);

             /*$setlrinvid=$this->lr_model->insertinvoiceid($setinvoice,$lrno);*/

             if($invoiceid > 0)
             {
                $this->session->set_flashdata('success', 'Invoice Updated successfully');
            }
            else
            {
                $this->session->set_flashdata('error', 'Invoice updatation failed');
            }

            redirect('viewinvoice');
        }

    }









public function archive($invid=null)
{


    $checkbalancedue=$this->invoice_model->getbalancedue($invid);
   
    if($checkbalancedue > 0)
    {
        $this->session->set_flashdata('error','unable to archive invoice ');
        redirect('viewinvoice');

    }
   else
   {
     $invdata= array('isarchive'=>1,);

    $result=$this->invoice_model->archive($invid,$invdata);

    if($result >0)
    {

        $this->session->set_flashdata('success','Invoice Archived successfully');


    }
    else
    {
        $this->session->set_flashdata('error','unable to archive invoice');
    }

    redirect('viewinvoice');

   }


}

public function unarchive($invid=null)
{

    $invdata= array('isarchive'=>0,);

    $result=$this->invoice_model->unarchive($invid,$invdata);

    if($result >0)
    {

        $this->session->set_flashdata('success','Invoice removed Successfully');


    }
    else
    {
        $this->session->set_flashdata('Error','Failed to  remove successfully');
    }

    redirect('viewinvoice');



}




function archiveinvListing()
    {


          $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->invoice_model->ainvListingCount($searchText);

            $returns = $this->paginationCompress ( "archivedinv/", $count, 10 );
            
            $data['invRecords'] = $this->invoice_model->ainvListing($searchText, $returns["page"], $returns["segment"]);

            $this->global['pageTitle'] = 'Shaurya Enterprises : Archived Invoices';
            
            $this->loadViews("archivedinv", $this->global, $data, NULL);

    }

    public function sendmail($lrno=null)
    {
        
        /*$data['mail']=$this->invoice_model->getinvoicebyidsingle($lrno);
        */
        $data['mail']=$this->invoice_model->getinvoicebyidformail($lrno);

        $custid=$data['mail']->custid;
        $data['custmailinfo']=$this->lr_model->getcustInfo($custid);
        $custemail=$data['custmailinfo']->email;
        if(file_exists("uploads/SE-".$lrno.".pdf"))
        {
            $filename="SE-".$lrno.".pdf";

            $this->send($custemail,$filename);
            



        }
        else
        {
            $this->downloadinvoice($lrno,$custid);
            $filename="SE-".$lrno.".pdf";

            
            $this->send($custemail,$filename);;

        }

        /* $this->global['pageTitle'] = 'Shaurya Enterprises : Mail LR';
         $this->loadViews("sendinvoice", $this->global,$data , NULL);*/
    }

    public function send($custemail=null,$filename=null)
 {
    $subject ="System Generated Invoice";
     
     
     
     

     if(!empty($custemail & $filename))
    {

        $message = '
         <h3 align="center">Your Invoice Details</h3>
         ';


          $config = Array(
         'protocol'  => 'smtp',
         'smtp_host' => 'mail.sieshatech.com',
         'smtp_port' => 587,
         'smtp_user' => 'ditrinity@sieshatech.com', 
         'smtp_pass' => 'ditrinity@19', 
         'mailtype'  => 'html',
         'charset'  => 'iso-8859-1',
         'wordwrap'  => TRUE
      );

         $this->load->library('email', $config);
         $this->email->set_newline("\r\n");
         $this->email->from("demo@gmail.com");
         $this->email->to($custemail);
         $this->email->subject($subject);
         $this->email->message($message);
         $this->email->attach("uploads/".$filename);
         
         if($this->email->send())
         {
            if(unlink("uploads/".$filename))
            {
           $this->session->set_flashdata('success', 'Mail sent');
           redirect('viewinvoice');
            }
            else
            {
                $this->session->set_flashdata('error', 'An error occured.attachment failed');
           redirect('viewinvoice');
                
            }
          
         }
         else
         {
           $this->session->set_flashdata('error', 'An error occured.Please check your internet connection');
           redirect('viewinvoice');
          
         }
     }
     else
     {
      $this->session->set_flashdata('error', 'An error occured invalid email/Attachment Not found');
         redirect('viewinvoice');
     }
 }


function upload_file()
 {
  $config['upload_path'] ='uploads';
  $config['allowed_types'] = 'doc|docx|pdf';
  $this->load->library('upload', $config);
  if($this->upload->do_upload('resume'))
  {
   return $this->upload->data();   
  }
  else
  {
   return $this->upload->display_errors();
  }
 }

 function dopayment($invid)
 {
            $data['invid']=$invid;
            $data['pmode']= $this->invoice_model->getpaymentmode();
            $this->global['pageTitle'] = 'Shaurya Enterprises : Make Payment';
            
            $this->loadViews("makepayment", $this->global, $data, NULL);



 }


 function makepayment()
 {

      $this->load->library('form_validation');
            $this->form_validation->set_rules('paymentmode','payment mode','max_length[100]');
            $this->form_validation->set_rules('transid','Transaction ID','max_length[100]');
            $this->form_validation->set_rules('invid','invid','numeric|max_length[100]');
            $this->form_validation->set_rules('amount','Amount','numeric|max_length[100]');


             if($this->form_validation->run() == FALSE)
        {
            redirect('viewinvoice');
        }
        else
        {
            $paymentmode = $this->input->post('paymentmode');
            $transid = $this->input->post('transid');
            $invid = $this->input->post('invid');
            $amount = $this->input->post('amount');

            $checktransid=$this->invoice_model->checktransid($transid);
            if($checktransid>0)
            {
               $this->session->set_flashdata('error','The transaction id is already exist.');
                redirect('viewinvoice'); 
            }

            
            $balancedue=$this->invoice_model->getbalancedue($invid);

            if($amount>$balancedue)
            {
                $this->session->set_flashdata('error','Enterd Ammount Exceeds Balance due,Please do valid payment.');
                redirect('viewinvoice');
            }

            if($balancedue==0)
            {
                $this->session->set_flashdata('error','Payment is recived for this invoice');
                redirect('viewinvoice');
            }


            $newbalancedue=$balancedue- $amount;

            $setbalancedue=array('balancedue'=>$newbalancedue,'updatedDtm'=>date('Y-m-d H:i:s'),'ispaymentdone'=>1);

            $payment=array('paidamount'=>$amount,'pmode'=>$paymentmode,'transactionid'=>$transid,'pdate'=>date('Y-m-d H:i:s'));


            $result=$this->invoice_model->updatepaymentinfo($invid,$payment);


            if($result>0)
             {
                $updatebalancedue=$this->invoice_model->updatedue($invid,$setbalancedue);

             $this->session->set_flashdata('success','Payment received Successfully');


            }
             else
             {
                $this->session->set_flashdata('Error','Failed to receive payment');
            }

              redirect('viewinvoice');


          }
         /* else
          {
            $this->session->set_flashdata('Error','Failed to recive payment');
            redirect('viewinvoice');

          }




        }*/


 }

 function paymentreport()
 {


            $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->invoice_model->getpaymentinfocount($searchText);

            $returns = $this->paginationCompress ( "paymentreport/", $count, 10 );
            
            $data['pRecords'] = $this->invoice_model->getpaymentinfo($searchText, $returns["page"], $returns["segment"]);

            $this->global['pageTitle'] = 'Shaurya Enterprises : Payment Reports';
            
            
            $this->loadViews("paymentreport", $this->global, $data, NULL);

 }



 /**
     * This function is used to print invoice
     * @param number $userId : Optional : This is user id
     */
function paymentrecipt($id = NULL)
{
        /*if($this->isAdmin() == TRUE || $id == 1)
        {
            $this->loadThis();
        }*/
        /*else
        {
        */    if($id == null)
            {
                redirect('paymentreport');
            }
            
            $data['lrinfo']=$this->invoice_model->getinvoicebyidsingle($id);
            $data['pinfo'] = $this->invoice_model->getpaymentprint($id);

            $this->global['pageTitle'] = 'Shaurya Enterprises : Edit User';


            $filename = time()."_precipt.pdf";
            
            $html = $this->load->view('paymentrecipt',$data,true);

// unpaid_voucher is unpaid_voucher.php file in view directory and $data variable has infor mation that you want to render on view.

            $this->load->library('M_pdf');

            $this->m_pdf->pdf->WriteHTML($html);

//download it D save F.

            $this->m_pdf->pdf->Output("./uploads/".$filename, "I"); 
            
            /*$this->loadViews("mypdf", $this->global, $data, NULL);*/
            /*}*/
        }




        function report()
        {
            $data['fdate']=NULL;
            $data['tdate']=NULL;
            $data['customer']=NULL;

            $data['lrRecords']=$this->lr_model->getalllrinfo();
            $this->global['pageTitle'] = 'Shaurya Enterprises : Reports';
            $this->loadViews("reports", $this->global, $data, NULL);

        }

         function balamount()
        {


            $data['lrRecords']=$this->lr_model->getalllrinfo();
            $this->global['pageTitle'] = 'Shaurya Enterprises : Reports';
            $this->loadViews("reportsbalanceamount", $this->global, $data, NULL);

        }

        function totalbalanceamount()
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('fromdate','date','required|max_length[100]');
            $this->form_validation->set_rules('todate','date','required|max_length[100]');
           

             if($this->form_validation->run() == FALSE)
        {
            $this->session->set_flashdata('Erro','Please select valid date');

            redirect('balamountreports');
        }
        else
        {
            $val=$this->input->post();
             $fromdate=$val['fromdate'];
             $todate=$val['todate'];

             $data['fdate']=$val['fromdate'];
             $data['tdate']=$val['todate'];

             $data['balinfo']=$this->invoice_model->getbalanceamount($fromdate,$todate);
            $data['invcount']=$this->invoice_model->getbalancecount($fromdate,$todate);
             $this->global['pageTitle'] = 'Shaurya Enterprises : Reports';
             $this->loadViews("reportsbalanceamount", $this->global, $data, NULL);
        }
        }
  

        function reportdata()

        {

            $this->load->library('form_validation');
            $this->form_validation->set_rules('customer','Select customer','required|max_length[100]');
            $this->form_validation->set_rules('fromdate','date','required|max_length[100]');
            $this->form_validation->set_rules('todate','date','required|max_length[100]');
           

             if($this->form_validation->run() == FALSE)
        {
            $this->session->set_flashdata('Error','Customername or date missing');
            redirect('reports');
        }
        else
        {

            $val=$this->input->post();

            $cust=$val['customer'];
            $fromdate=$val['fromdate'];
            $todate=$val['todate'];
            $data['fdate']=$val['fromdate'];
            $data['tdate']=$val['todate'];
            $data['customer']=$val['customer'];

            $data['lrRecords']=$this->lr_model->getalllrinfo();
             $data['repoRecords']=$this->invoice_model->getreports($cust,$fromdate,$todate);
             /*print_r($data['repoRecords']);*/
             if( empty($data['repoRecords'] and $data['lrRecords']))
             {
             $this->session->set_flashdata('error','No records found');
             }
             $this->global['pageTitle'] = 'Shaurya Enterprises : Reports';
            $this->loadViews("reports", $this->global, $data, NULL);

             




        }
        }

            function excel()
            {

        $this->load->library('excel');
        //activate worksheet number 1
        $this->excel->setActiveSheetIndex(0);
        //name the worksheet
        $this->excel->getActiveSheet()->setTitle('Users list');
        $users = $this->invoice_model->getinvoicebyid(0001);
 
        // read data to active sheet
        
        // read data to active sheet
        $this->excel->getActiveSheet()->fromArray($users);
        
        $filename='just_some_random_name.xlsx'; //save our workbook as this file name
        
        
                    
        //save it to Excel5 format (excel 2003 .XLS file), change this to 'Excel2007' (and adjust the filename extension, also the header mime type)
        //if you want to save it as.XLSX Excel 2007 format
 
        $objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel2007'); 
        ob_end_clean();
        
        //force user to download the Excel file without writing it to server's HD
        $objWriter->save('php://output');
            }





}

?>
