<?php defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . '/libraries/BaseController.php';


class Sendlr extends BaseController {

public function index()
 {

  		$this->global['pageTitle'] = 'Shaurya Enterprises : Dashboard';


        
        $this->loadViews("sendemail", $this->global,NULL , NULL);
 }

 /*public function send()
 {
 	$subject ="System Generated LR";
 	 $file_data = $this->upload_file();

 	 if(is_array($file_data))
  	{

  		$message = '
  		 <h3 align="center">Programmer Details</h3>
  		 ';


  		  $config = Array(
         'protocol'  => 'smtp',
         'smtp_host' => 'mail.sieshatech.com',
         'smtp_port' => 587,
         'smtp_user' => 'ditrinity@sieshatech.com', 
         'smtp_pass' => 'ditrinity@19', 
         'mailtype'  => 'html',
         'charset'  => 'iso-8859-1',
         'wordwrap'  => TRUE
      );

  		  $this->load->library('email', $config);
      $this->email->set_newline("\r\n");
      $this->email->from($this->input->post("email"));
      $this->email->to('web-tutorial@programmer.net');
      $this->email->subject($subject);
         $this->email->message($message);
         $this->email->attach($file_data['full_path']);
         if($this->email->send())
         {
          if(delete_files($file_data['file_path']))
          {
           $this->session->set_flashdata('message', 'Application Sended');
           redirect('extracopy');
          }
         }
         else
         {
          if(delete_files($file_data['file_path']))
          {
           $this->session->set_flashdata('message', 'There is an error in email send');
           redirect('extracopy');
          }
         }
     }
     else
     {
      $this->session->set_flashdata('message', 'There is an error in attach file');
         redirect('sendemail');
     }
 }*/

 function upload_file()
 {
  $config['upload_path'] = 'uploads/';
  $config['allowed_types'] = 'doc|docx|pdf';
  $this->load->library('upload', $config);
  if($this->upload->do_upload('resume'))
  {
   return $this->upload->data();   
  }
  else
  {
   return $this->upload->display_errors();
  }
 }
}
?>

