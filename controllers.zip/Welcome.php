<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . '/libraries/BaseController.php';
class Welcome extends BaseController {

	public function __construct()
    {
        parent::__construct();
        $this->load->model('user_model');
        $this->load->model('cust_model');
        $this->load->model('lr_model');
        $this->load->model('invoice_model');
        $this->load->library('pdf');
        $this->load->library('excel');
        $this->isLoggedIn();   
        $this->session->keep_flashdata('message');
        
    }
    public function createXLS() {
		// create file name
        $fileName = 'Reports-'.time().'.xlsx';  
		// load excel library
        $this->load->library('excel');
        $empInfo = json_encode($this->user_model->custInfo());
        $cInfo=json_decode($empInfo,true);


        $objPHPExcel = new PHPExcel();
        $objPHPExcel->setActiveSheetIndex(0);
        // set Head
        $objPHPExcel->getActiveSheet()->SetCellValue('A1', 'Customer Type');
        $objPHPExcel->getActiveSheet()->SetCellValue('B1', 'Customer Name');
        $objPHPExcel->getActiveSheet()->SetCellValue('C1', 'Address Line1');
        $objPHPExcel->getActiveSheet()->SetCellValue('D1', 'Address Line2');
        $objPHPExcel->getActiveSheet()->SetCellValue('E1', 'City');       
        $objPHPExcel->getActiveSheet()->SetCellValue('F1', 'State');       
        $objPHPExcel->getActiveSheet()->SetCellValue('G1', 'PAN');
        $objPHPExcel->getActiveSheet()->SetCellValue('H1', 'Pincode');


        // set Row
        $rowCount = 2;
        foreach ($cInfo as $element) {
            $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCount, $element['customertype']);
            $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowCount, $element['customername']);
            $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowCount, $element['address1']);
            $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowCount, $element['address2']);
            $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowCount, $element['city']);
            $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowCount, $element['state']);
            $objPHPExcel->getActiveSheet()->SetCellValue('G' . $rowCount, $element['pan']);
            $objPHPExcel->getActiveSheet()->SetCellValue('H' . $rowCount, $element['pincode']);
            $rowCount++;
        }
        $objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
        $objWriter->save("uploads/".$fileName);
		// download file
        
        
    }

    public function custwisereport($fromdate,$todate,$cust)
    {
    	

    	 $fileName = 'CustomerReport-'.time().'.xlsx';  
		// load excel library
        $this->load->library('excel');
        $custRecords=$this->invoice_model->getreports($cust,$fromdate,$todate);
        $crInfo = json_encode($custRecords);
        
        $crecords=json_decode($crInfo,true);


        $objPHPExcel = new PHPExcel();
        $objPHPExcel->setActiveSheetIndex(0);
        // set Head
        $objPHPExcel->getActiveSheet()->SetCellValue('A1', 'Customer Name');
        $objPHPExcel->getActiveSheet()->SetCellValue('B1', 'Date');
        $objPHPExcel->getActiveSheet()->SetCellValue('C1', 'Invoice no');
        $objPHPExcel->getActiveSheet()->SetCellValue('D1', 'Total Amount');
        $objPHPExcel->getActiveSheet()->SetCellValue('E1', 'Due Amount');       
        

        // set Row
        $rowCount = 2;
        foreach ($crecords as $element) {
            $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCount, $element['customername']);
            $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowCount, $element['date']);
            $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowCount, $element['invid']);
            $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowCount, $element['total']);
            $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowCount, $element['balancedue']);
            
            $rowCount++;
        }


        /*$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
        $objWriter->save($fileName);
        header("Content-Type: application/vnd.ms-excel");
        redirect(HTTP_UPLOAD_IMPORT_PATH.$fileName);
        */
              header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="'.$fileName.'"');
header('Cache-Control: max-age=0');
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
$objWriter->save('php://output');

        
    	
    }

    function bamountreport($fromdate,$todate)
    {

    	

    	$fileName = 'BalanceamountReport-'.time().'.xlsx';  
		// load excel library
        $this->load->library('excel');
        $custRecords=$this->invoice_model->getbalanceamount($fromdate,$todate);
        $crInfo = json_encode($custRecords);
        
        $crecords=json_decode($crInfo,true);


        $objPHPExcel = new PHPExcel();
        $objPHPExcel->setActiveSheetIndex(0);
        // set Head
        $objPHPExcel->getActiveSheet()->SetCellValue('A1', 'Customer Name');
        $objPHPExcel->getActiveSheet()->SetCellValue('B1', 'Total Invoice Amount');
        $objPHPExcel->getActiveSheet()->SetCellValue('C1', 'Total Balance Due');
        

        // set Row
        $rowCount = 2;
        foreach ($crecords as $element) {
            $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCount, $element['customername']);
            $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowCount, $element['total']);
            $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowCount, $element['balancedue']);
            
            $rowCount++;
        }


       /* $objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
        $objWriter->save($fileName);
        header("Content-Type: application/vnd.ms-excel");
        redirect(HTTP_UPLOAD_IMPORT_PATH.$fileName);*/
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="'.$fileName.'"');
header('Cache-Control: max-age=0');
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
$objWriter->save('php://output');

    }



    public function lrreport($fromdate,$todate,$cust)
    {
    	

    	 $fileName = 'LrReport-'.time().'.xlsx';  
		// load excel library
        $this->load->library('excel');
        $custRecords=$this->lr_model->getLrbycustomer($cust,$fromdate,$todate);
        $crInfo = json_encode($custRecords);
        
        $crecords=json_decode($crInfo,true);


        $objPHPExcel = new PHPExcel();
        $objPHPExcel->setActiveSheetIndex(0);
        // set Head
        $objPHPExcel->getActiveSheet()->SetCellValue('A1', 'LR NO');
        $objPHPExcel->getActiveSheet()->SetCellValue('B1', 'LR Date');
        $objPHPExcel->getActiveSheet()->SetCellValue('C1', 'From');
        $objPHPExcel->getActiveSheet()->SetCellValue('D1', 'To');
        $objPHPExcel->getActiveSheet()->SetCellValue('E1', 'Vehicle');
        $objPHPExcel->getActiveSheet()->SetCellValue('F1', 'Driver');       
        

        // set Row
        $rowCount = 2;
        foreach ($crecords as $element) {
            $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCount, $element['lrno']);
            $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowCount, $element['createdDtm']);
            $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowCount, $element['city']);
            $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowCount, $element['consigneecity']);
            $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowCount, $element['vtype']);
            $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowCount, $element['driver']);
            
            $rowCount++;
        }


        /*$objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
        $objWriter->save($fileName);
        header("Content-Type: application/vnd.ms-excel");
        redirect(HTTP_UPLOAD_IMPORT_PATH.$fileName);
        */
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="'.$fileName.'"');
header('Cache-Control: max-age=0');
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
$objWriter->save('php://output');
      

        
    	
    }
 


 }

?>