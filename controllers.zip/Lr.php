<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';
require_once APPPATH . '/libraries/Pdf.php';
class Lr extends BaseController
{
	 public function __construct()
    {
        parent::__construct();
        $this->load->model('user_model');
        $this->load->model('cust_model');
        $this->load->model('lr_model');
        $this->load->library('pdf');
        $this->isLoggedIn();   
        $this->session->keep_flashdata('message');
    }

    public function index()
    {
        if($this->isAdmin() == TRUE || $this->isUser() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
        $this->global['pageTitle'] = 'Shaurya Enterprises : LR Generation';
        $this->loadViews("lrdashboard", $this->global, NULL , NULL);
        }

    }


 function downloadlrview($id = NULL,$custid=null)
    {
        /*if($this->isAdmin() == TRUE || $id == 1)
        {
            $this->loadThis();
        }*/
        /*else
        {
        */    
            if($id == null & $custid == null)
            {
                redirect('lrListing');
            }
            $ctype = $this->user_model->getcusttype($custid);

            if($ctype=='Regular')
            {
                $data['compinfo']=$this->user_model->getcompinfo();
          
            $data['lrinfo'] = $this->lr_model->getlrInfop($id);
            
            $this->global['pageTitle'] = 'Shaurya Enterprises : Edit User';


            $this->pdf->load_view_save('maillr',$data,$id);
            }

            else
            {
                $data['compinfo']=$this->user_model->getcompinfo();
                $data['lrinfo'] = $this->lr_model->getlrInfop($id);
                $datap = $this->lr_model->getlrInfoftv($id);
                $fromc=$datap->city;
                $toc=$datap->consigneecity;
                $vtype=$datap->vtype;

                $data['getfreightc']=$this->lr_model->getfreightc($fromc,$toc,$vtype,$custid);

                
            
            $this->global['pageTitle'] = 'Shaurya Enterprises : Edit User';


            $this->pdf->load_view_save('maillrc',$data,$id);

            }

            
            /*$this->loadViews("mypdf", $this->global, $data, NULL);*/
        /*}*/
    }

 public function sendmail($lrno=null,$custid=null)
    {
        

        $data['mail']=$this->lr_model->getlrInfomail($lrno);
        $custid=$data['mail']->custid;
        $data['custmailinfo']=$this->lr_model->getcustInfo($custid);
        $custemail=$data['custmailinfo']->email;
        
        if(file_exists("uploads/SE-".$lrno.".pdf"))
        {
            $filename="LR-".$lrno.".pdf";
            

            $this->send($custemail,$filename);
            



        }
        else
        {
            $this->downloadlrview($lrno,$custid);
            $filename="LR-".$lrno.".pdf";

            
            $this->send($custemail,$filename);

        }

        
         /*$this->global['pageTitle'] = 'Shaurya Enterprises : LR Generation';
         $this->loadViews("sendnewmail", $this->global,$data , NULL);*/
    }


 public function send($custemail,$filename)
 {
    $subject ="System Generated LR";
     if(!empty($custemail & $filename))
    {

        $message = '
         <h3 align="center">Your LR Details</h3>
         ';


          $config = Array(
         'protocol'  => 'smtp',
         'smtp_host' => 'mail.sieshatech.com',
         'smtp_port' => 587,
         'smtp_user' => 'ditrinity@sieshatech.com', 
         'smtp_pass' => 'ditrinity@19', 
         'mailtype'  => 'html',
         'charset'  => 'iso-8859-1',
         'wordwrap'  => TRUE
      );

         $this->load->library('email', $config);
         $this->email->set_newline("\r\n");
         $this->email->from("demo@gmail.com");
         $this->email->to($custemail);
         $this->email->subject($subject);
         $this->email->message($message);
         $this->email->attach("uploads/".$filename);
         
         if($this->email->send())
         {
            if(unlink("uploads/".$filename))
            {
           $this->session->set_flashdata('success', 'Mail sent');
           redirect('lrlisting');
            }
            else
            {
                $this->session->set_flashdata('error', 'An error occured.Attachement Failed');
           redirect('lrlisting');
          
            }
          
         }
         else
         {
           $this->session->set_flashdata('error', 'An error occured.Please check your Internet Connection');
           redirect('lrlisting');
          
         }
     }
     else
     {
      $this->session->set_flashdata('error', 'An error occured.Invalid email/Attachement Not Found');
         redirect('lrlisting');
     }
 }


function upload_file()
 {
  $config['upload_path'] ='uploads';
  $config['allowed_types'] = 'doc|docx|pdf';
  $this->load->library('upload', $config);
  if($this->upload->do_upload('resume'))
  {
   return $this->upload->data();   
  }
  else
  {
   return $this->upload->display_errors();
  }
 }
    
public function lrgen()
    {
    	  $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->cust_model->custListingCount($searchText);

            $returns = $this->paginationCompress ( "lrdashboard/", $count, 10 );
            
            $data['custRecords'] = $this->cust_model->custListing($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'Shaurya Enterprises : User Listing';
            
            $this->loadViews("lrdashboard", $this->global, $data, NULL);
       
    }  

    function mypdf(){

        $this->global['pageTitle'] = 'Shaurya Enterprises : Dashboard';
        
        $this->loadViews("bill", $this->global, NULL , NULL);
   
   }  

   function archive($lrno = NULL)
   {
              if($lrno == null)
                {
                redirect('lrListing');
                }


                $checkinvoice=$this->lr_model->getinvoice($lrno);
            

                if($checkinvoice >0)
                {
                  $checkbalancedue=$this->lr_model-> getbalancedue($lrno);
                  if($checkbalancedue==0)
                  {
                    $archivelr=array('archive'=>1);
                $result = $this->lr_model->archive($archivelr,$lrno);

              if($result >0)
                {
                    $this->session->set_flashdata('success', 'LR archived successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Unable to archive.');
                }
                
                redirect('lrlisting');


                  }
                  else
                  {
                    $this->session->set_flashdata('error', ' Unable to archive Payment is Pending.');
                    redirect('lrlisting');
                  }
                
                }
                else
                {
                   $archivelr=array('archive'=>1);
                $result = $this->lr_model->archive($archivelr,$lrno);

              if($result >0)
                {
                    $this->session->set_flashdata('success', 'LR archived successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Unable to archive');
                }
                
                redirect('lrlisting');

                }


              

                  



               
   }  


   function unarchive($lrno = NULL){
     if($lrno == null)
            {
                redirect('archived');
            }

              $archivelr=array('archive'=>0);
              $result = $this->lr_model->unarchive($archivelr,$lrno);

              if($result >0)
                {
                    $this->session->set_flashdata('success', 'LR Unarchived successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Unable to Unarchive LR');
                }
                
                redirect('archived');
   
   }  







   function archivelrListing()
    {
        /*if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }*/
        /*else
        {        
        */    $searchText = $this->security->xss_clean($this->input->post('searchText'));
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->lr_model->archlrListingCount($searchText);

            $returns = $this->paginationCompress ( "archived/", $count, 10 );
            
            $data['lrRecords'] = $this->lr_model->archlrListing($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'Shaurya Enterprises : User Listing';
            
            $this->loadViews("archivedlr", $this->global, $data, NULL);
        /*}*/
    }


    function setdeliverystatus($lr=null)
    {
      if($lr==null)
      {
        redirect("dashboard");
      }
      else
      {

      $status=array("status"=>"delivered");

      $result=$this->lr_model->setdeliverystatus($status,$lr);

      if($result > 0)
                {
                    $this->session->set_flashdata('success', 'Status changed  successfully');
                    redirect("dashboard");
                }
                else
                {
                    $this->session->set_flashdata('error', 'fail to change status');
                    redirect("dashboard");
                }



    }




    }





    function addnewlr()
    {
    

        /*if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }*/
       
                    $this->load->library('form_validation');
            $this->form_validation->set_rules('custId','Customer id','trim|required|max_length[500]');
            $this->form_validation->set_rules('cname','Customer Name','trim|required|max_length[500]');
            $this->form_validation->set_rules('address1','Address 1','trim|required|max_length[128]');
            $this->form_validation->set_rules('address2','Address 2','trim|required|max_length[128]');
            $this->form_validation->set_rules('city','City','trim|required|max_length[100]');
            $this->form_validation->set_rules('state','State','trim|required|max_length[100]');
            $this->form_validation->set_rules('pan','PAN','trim|required|max_length[10]|min_length[10]');
            $this->form_validation->set_rules('Email','Email','trim|required|valid_email');
            $this->form_validation->set_rules('pincode','Pincode','trim|required|numeric|max_length[6]');
            $this->form_validation->set_rules('GSTNO','GST NO','required|max_length[15]');
            $this->form_validation->set_rules('cft','CFT','numeric|max_length[100]');
            $this->form_validation->set_message('check_duplicate_email', 'This customer is alreadyexist. Please write a new email.');
            $this->form_validation->set_rules('blc','Bilty Charges','trim|max_length[20]');
            $this->form_validation->set_rules('frt','Freight','trim|max_length[20]');
            $this->form_validation->set_rules('serc','Ser.Charge','trim|max_length[20]');
            $this->form_validation->set_rules('vlc','Vehichle Type','trim|required|max_length[200]');
            $this->form_validation->set_rules('vlcno','Vehichle No','trim|required|max_length[200]');
            $this->form_validation->set_rules('driver','Driver','trim|required|max_length[200]');
            $this->form_validation->set_rules('lisc','Licsence No','trim|max_length[200]');
            $this->form_validation->set_rules('sealno','Seal no','trim|required|max_length[20]');
            $this->form_validation->set_rules('riskselect','Risk','trim|required|max_length[40]');
            $this->form_validation->set_rules('mode','Transport Mode','trim|required|max_length[20]');
            $this->form_validation->set_rules('tdelivery','Type of Delivery','trim|required|max_length[30]');
            $this->form_validation->set_rules('ddate','Document Date','trim|required|max_length[20]'); 
            $this->form_validation->set_rules('dincno','Invoice No','trim|required|max_length[20]');     
            $this->form_validation->set_rules('dincnv','Invoice Value','trim|required|max_length[20]');  
            $this->form_validation->set_rules('icompname','Company Name','trim|max_length[200]');  
            $this->form_validation->set_rules('amt','Amount','trim|max_length[200]');  
            $this->form_validation->set_rules('policyno','Policy No','trim|max_length[200]');  
            $this->form_validation->set_rules('idate','Date','trim|max_length[200]'); 
            $this->form_validation->set_rules('irisk','Ins.Risk','trim|max_length[200]'); 
            $this->form_validation->set_rules('consigneename','Consignee Name','trim|required|max_length[200]');
            $this->form_validation->set_rules('consigneeadd','Consignee Address','trim|required|max_length[200]'); 
            $this->form_validation->set_rules('street','Street','trim|required|max_length[200]'); 
            $this->form_validation->set_rules('land','Landmark','trim|max_length[200]'); 
            $this->form_validation->set_rules('ccity','City','trim|required|max_length[200]'); 
            $this->form_validation->set_rules('cpincode','Pincode','trim|required|max_length[6]'); 
            $this->form_validation->set_rules('nog','Nature of Goods','trim|required|max_length[200]'); 
            $this->form_validation->set_rules('cqty','Quantity(In no.)','trim|required|max_length[10]'); 
            $this->form_validation->set_rules('weight','Weight(In Kgs)','trim|required|max_length[10]');
            $this->form_validation->set_rules('remark','Remark','trim|max_length[200]');
            $this->form_validation->set_rules('riskselect','Risk','trim|required|max_length[200]');
            $this->form_validation->set_rules('conp','Contact Person','trim|required|max_length[200]');
            $this->form_validation->set_rules('conpno','ContactNo','trim|required|max_length[10]');
            $this->form_validation->set_rules('conpnob','ContactNo','trim|max_length[10]');
            $this->form_validation->set_rules('conpnoc','ContactNo','trim|max_length[10]');
            $this->form_validation->set_rules('freightcharges','Freight Charges','trim|max_length[10]');
            $this->form_validation->set_rules('payableat','Freight Charges','trim|max_length[10]');
            $this->form_validation->set_rules('exdelivery','Expected days for delivery','trim|max_length[10]');


            if($this->form_validation->run() == FALSE)
            {
                $this->lrgen();
            }

            else
            {   $custid= $this->input->post('custId');
                $cname = ucwords(strtolower($this->security->xss_clean($this->input->post('cname'))));
                $address1= $this->input->post('address1');
                $address2= $this->input->post('address2');
                $city= $this->input->post('city');
                $email = strtolower($this->security->xss_clean($this->input->post('Email')));
                $pincode= $this->input->post('pincode');
                $gstno= $this->input->post('GSTNO');
                $cft= $this->input->post('cft');
                $state=$this->input->post('state');
                $pan=$this->input->post('pan');
                $consigneename=$this->input->post('consigneename');
                $conadd=$this->input->post('consigneeadd');
                $street=$this->input->post('street');
                $land=$this->input->post('land');
                $ccity=$this->input->post('ccity');
                $cpincode=$this->input->post('cpincode');
                $nog=$this->input->post('nog');
                $cqty=$this->input->post('cqty');
                $weight=$this->input->post('weight');
                $remark=$this->input->post('remark');
                $ccft=$this->input->post('cft');
                $bilty=$this->input->post('blc');
                $freight=$this->input->post('frt');
                $serc=$this->input->post('serc');
                $vtype=$this->input->post('vlc');
                $vlcno=$this->input->post('vlcno');
                $driver=$this->input->post('driver');
                $lisc=$this->input->post('lisc');
                $sealno=$this->input->post('sealno');
                $risk=$this->input->post('riskselect');
                $tmode=$this->input->post('mode');
                $tdel=$this->input->post('tdelivery');
                $ddate=date('Y-m-d', strtotime( $this->input->post('ddate') ) );
                $incno=$this->input->post('dincno');
                $incvl=$this->input->post('dincnv');
                $icomp=$this->input->post('icompname');
                $iamt=$this->input->post('amt');
                $policyno=$this->input->post('policyno');
               
                $irisk=$this->input->post('irisk');
                $conp=$this->input->post('conp');
                $conpno=$this->input->post('conpno');
                $conpnob=$this->input->post('conpnob');
                $conpnoc=$this->input->post('conpnoc');
                $freightc=$this->input->post('freightcharges');
                $payableat=$this->input->post('payableat');
                $expdate=$this->input->post('expdate');
                $subjectto=$this->input->post('subjectto');
                /*$deliverydate = date('Y-m-d',strtotime('+'$expdays'. days',$date));
*/

                 $idate=$this->input->post('idate');
              if(empty($idate))
              {
                if(empty($expdate))
                {
                  $indate=NULL;
                  $exdate=NULL;
                   $LrInfo = array('customername'=>$cname, 'address1'=>$address1, 'address2'=>$address2, 'city'=> $city,'state'=>$state,'pan'=>$pan,'pincode'=>$pincode, 'email'=>$email, 'gstno'=>$gstno,'cft'=>$cft,'contactperson'=>$conp,'contactpersonno'=>$conpno,'contactpersonnob'=>$conpnob,'contactpersonnoc'=>$conpnoc,'consigneename'=>$consigneename,'consigneeadd'=>$conadd,'street'=>$street,
                    'landmark'=>$land,'consigneecity'=>$ccity,'consigneepincode'=>$cpincode,
                    'nog'=>$nog,'qty'=>$cqty,'weight'=>$weight,'remark'=>$remark,'consigneecft'=>$ccft,'bilty'=>$bilty,'freight'=>$freight,'ser'=>$serc,'vtype'=>$vtype,'vno'=>$vlcno,
                    'driver'=>$driver,'licsno'=>$lisc,'sealno'=>$sealno,'risk'=>$risk,'subjectto'=>$subjectto,
                    'mode'=>$tmode,'tdel'=>$tdel,'ddate'=>$ddate,'incno'=>$incno,'pdate'=>$indate,
                    'incval'=>$incvl,'icomp'=>$icomp,'iamount'=>$iamt,'policyno'=>$policyno,'freightchar'=>$freightc,
                    'prisk'=>$irisk,'createdDtm'=>date('Y-m-d H:i:s'),'payableat'=>$payableat,'custid'=>$custid,'expectedddate'=>$exdate/*'expectedddate'=>$$deliverydate */
                    );

                }
                else
                {
                  $exdate=date('Y-m-d', strtotime($expdate) );
                  $LrInfo = array('customername'=>$cname, 'address1'=>$address1, 'address2'=>$address2, 'city'=> $city,'state'=>$state,'pan'=>$pan,'pincode'=>$pincode, 'email'=>$email, 'gstno'=>$gstno,'cft'=>$cft,'contactperson'=>$conp,'contactpersonno'=>$conpno,'contactpersonnob'=>$conpnob,'contactpersonnoc'=>$conpnoc,'consigneename'=>$consigneename,'consigneeadd'=>$conadd,'street'=>$street,
                    'landmark'=>$land,'consigneecity'=>$ccity,'consigneepincode'=>$cpincode,
                    'nog'=>$nog,'qty'=>$cqty,'weight'=>$weight,'remark'=>$remark,'consigneecft'=>$ccft,'bilty'=>$bilty,'freight'=>$freight,'ser'=>$serc,'vtype'=>$vtype,'vno'=>$vlcno,
                    'driver'=>$driver,'licsno'=>$lisc,'sealno'=>$sealno,'risk'=>$risk,'subjectto'=>$subjectto,
                    'mode'=>$tmode,'tdel'=>$tdel,'ddate'=>$ddate,'incno'=>$incno,
                    'incval'=>$incvl,'icomp'=>$icomp,'iamount'=>$iamt,'policyno'=>$policyno,'freightchar'=>$freightc,
                    'prisk'=>$irisk,'createdDtm'=>date('Y-m-d H:i:s'),'payableat'=>$payableat,'custid'=>$custid,'expectedddate'=>$exdate 
                    );


                }

               
              }
              else
              {
                $indate=date('Y-m-d', strtotime($idate) );
                if(empty($expdate))
                {

                $exdate=NULL;
                $LrInfo = array('customername'=>$cname, 'address1'=>$address1, 'address2'=>$address2, 'city'=> $city,'state'=>$state,'pan'=>$pan,'pincode'=>$pincode, 'email'=>$email, 'gstno'=>$gstno,'cft'=>$cft,'contactperson'=>$conp,'contactpersonno'=>$conpno,'contactpersonnob'=>$conpnob,'contactpersonnoc'=>$conpnoc,'consigneename'=>$consigneename,'consigneeadd'=>$conadd,'street'=>$street,
                    'landmark'=>$land,'consigneecity'=>$ccity,'consigneepincode'=>$cpincode,
                    'nog'=>$nog,'qty'=>$cqty,'weight'=>$weight,'remark'=>$remark,'consigneecft'=>$ccft,'bilty'=>$bilty,'freight'=>$freight,'ser'=>$serc,'vtype'=>$vtype,'vno'=>$vlcno,
                    'driver'=>$driver,'licsno'=>$lisc,'sealno'=>$sealno,'risk'=>$risk,'subjectto'=>$subjectto,
                    'mode'=>$tmode,'tdel'=>$tdel,'ddate'=>$ddate,'incno'=>$incno,
                    'incval'=>$incvl,'icomp'=>$icomp,'iamount'=>$iamt,'policyno'=>$policyno,'freightchar'=>$freightc,
                    'pdate'=>$indate,'prisk'=>$irisk,'createdDtm'=>date('Y-m-d H:i:s'),'payableat'=>$payableat,'custid'=>$custid, 'expectedddate'=>$exdate/*'expectedddate'=>$$deliverydate*/
                    );
                }
                else
                {
                  $exdate=date('Y-m-d', strtotime($expdate) );
                  $LrInfo = array('customername'=>$cname, 'address1'=>$address1, 'address2'=>$address2, 'city'=> $city,'state'=>$state,'pan'=>$pan,'pincode'=>$pincode, 'email'=>$email, 'gstno'=>$gstno,'cft'=>$cft,'contactperson'=>$conp,'contactpersonno'=>$conpno,'contactpersonnob'=>$conpnob,'contactpersonnoc'=>$conpnoc,'consigneename'=>$consigneename,'consigneeadd'=>$conadd,'street'=>$street,
                    'landmark'=>$land,'consigneecity'=>$ccity,'consigneepincode'=>$cpincode,
                    'nog'=>$nog,'qty'=>$cqty,'weight'=>$weight,'remark'=>$remark,'consigneecft'=>$ccft,'bilty'=>$bilty,'freight'=>$freight,'ser'=>$serc,'vtype'=>$vtype,'vno'=>$vlcno,
                    'driver'=>$driver,'licsno'=>$lisc,'sealno'=>$sealno,'risk'=>$risk,'subjectto'=>$subjectto,
                    'mode'=>$tmode,'tdel'=>$tdel,'ddate'=>$ddate,'incno'=>$incno,
                    'incval'=>$incvl,'icomp'=>$icomp,'iamount'=>$iamt,'policyno'=>$policyno,'freightchar'=>$freightc,
                    'pdate'=>$indate,'prisk'=>$irisk,'createdDtm'=>date('Y-m-d H:i:s'),'payableat'=>$payableat,'custid'=>$custid,'expectedddate'=>$exdate 
                    );

                }
                
              }
                /*$customercheck=$this->cust_model->cust_exists($gstno);*/
                
                
                $this->load->model('lr_model');
                $result = $this->lr_model->addNewlr($LrInfo);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'LR Created successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Customer creation failed');
                }
                
                redirect('lrlisting');
            }
        
    }


/*Editexlr*/
function editexlrf()
    {    
            $this->load->library('form_validation');
            $lrno = $this->input->post('lrno');

            $this->form_validation->set_rules('cft','CFT','numeric|max_length[100]');
            $this->form_validation->set_message('check_duplicate_email', 'This customer is alreadyexist. Please write a new email.');
            $this->form_validation->set_rules('blc','Bilty Charges','trim|max_length[20]');
            $this->form_validation->set_rules('frt','Freight','trim|max_length[20]');
            $this->form_validation->set_rules('serc','Ser.Charge','trim|max_length[20]');
            $this->form_validation->set_rules('vlc','Vehichle Type','trim|required|max_length[200]');
            $this->form_validation->set_rules('vlcno','Vehichle No','trim|required|max_length[200]');
            $this->form_validation->set_rules('driver','Driver','trim|required|max_length[200]');
            $this->form_validation->set_rules('lisc','Licsence No','trim|max_length[200]');
            $this->form_validation->set_rules('sealno','Seal no','trim|required|max_length[20]');
            $this->form_validation->set_rules('riskselect','Risk','trim|required|max_length[40]');
            $this->form_validation->set_rules('mode','Transport Mode','trim|required|max_length[20]');
            $this->form_validation->set_rules('tdelivery','Type of Delivery','trim|required|max_length[30]');
            $this->form_validation->set_rules('ddate','Document Date','trim|required|max_length[20]'); 
            $this->form_validation->set_rules('dincno','Invoice No','trim|required|max_length[20]');     
            $this->form_validation->set_rules('dincnv','Invoice Value','trim|required|max_length[20]');  
            $this->form_validation->set_rules('icompname','Company Name','trim|max_length[200]');  
            $this->form_validation->set_rules('amt','Amount','trim|max_length[200]');  
            $this->form_validation->set_rules('policyno','Policy No','trim|max_length[200]');  
            $this->form_validation->set_rules('idate','Date','trim|max_length[20]'); 
            $this->form_validation->set_rules('irisk','Ins.Risk','trim|max_length[200]'); 
            $this->form_validation->set_rules('consigneename','Consignee Name','trim|required|max_length[200]');
            $this->form_validation->set_rules('consigneeadd','Consignee Address','trim|required|max_length[200]'); 
            $this->form_validation->set_rules('street','Street','trim|required|max_length[200]'); 
            $this->form_validation->set_rules('land','Landmark','trim|max_length[200]'); 
            $this->form_validation->set_rules('ccity','City','trim|required|max_length[200]'); 
            $this->form_validation->set_rules('cpincode','Pincode','trim|required|max_length[6]'); 
            $this->form_validation->set_rules('nog','Nature of Goods','trim|required|max_length[200]'); 
            $this->form_validation->set_rules('cqty','Quantity(In no.)','trim|required|max_length[10]'); 
            $this->form_validation->set_rules('weight','Weight(In Kgs)','trim|required|max_length[10]');
            $this->form_validation->set_rules('remark','Remark','trim|max_length[200]');
            $this->form_validation->set_rules('riskselect','Risk','trim|required|max_length[200]');
            $this->form_validation->set_rules('conp','Contact Person','trim|required|max_length[200]');
            $this->form_validation->set_rules('conpno','ContactNo','trim|required|max_length[10]');
             $this->form_validation->set_rules('conpnob','Contact No 2','trim|max_length[10]');
            $this->form_validation->set_rules('conpnoc','Contact No 3','trim|max_length[10]');


            if($this->form_validation->run() == FALSE)
            {
                $this->lrgen();
            }
            else
            {
                $cft= $this->input->post('cft');
                $consigneename=$this->input->post('consigneename');
                $conadd=$this->input->post('consigneeadd');
                $street=$this->input->post('street');
                $land=$this->input->post('land');
                $ccity=$this->input->post('ccity');
                $cpincode=$this->input->post('cpincode');
                $nog=$this->input->post('nog');
                $cqty=$this->input->post('cqty');
                $weight=$this->input->post('weight');
                $remark=$this->input->post('remark');
                $ccft=$this->input->post('cft');
                $bilty=$this->input->post('blc');
                $freight=$this->input->post('frt');
                $serc=$this->input->post('serc');
                $vtype=$this->input->post('vlc');
                $vlcno=$this->input->post('vlcno');
                $driver=$this->input->post('driver');
                $lisc=$this->input->post('lisc');
                $sealno=$this->input->post('sealno');
                $risk=$this->input->post('riskselect');
                $tmode=$this->input->post('mode');
                $tdel=$this->input->post('tdelivery');
                $ddate=date('Y-m-d', strtotime( $this->input->post('ddate') ) );
                $incno=$this->input->post('dincno');
                $incvl=$this->input->post('dincnv');
                $icomp=$this->input->post('icompname');
                $iamt=$this->input->post('amt');
                $policyno=$this->input->post('policyno');
              
                $irisk=$this->input->post('irisk');
                $conp=$this->input->post('conp');
                $conpno=$this->input->post('conpno');
                $conpnob=$this->input->post('conpnob');
                $conpnoc=$this->input->post('conpnoc');
                /*$customercheck=$this->cust_model->cust_exists($gstno);*/
                
                $expdate=$this->input->post('expdate');
                $subjectto=$this->input->post('subjectto');
               $idate=$this->input->post('idate');
               $payableat=$this->input->post('payableat');
                if(empty($idate))
                {
                 if(empty($expdate))
                 { 
                  $indate=NULL;
                  $exdate=NULL;
                $LrInfo = array('cft'=>$cft,'contactperson'=>$conp,'contactpersonno'=>$conpno,'contactpersonnob'=>$conpnob,'contactpersonnoc'=>$conpnoc,'consigneename'=>$consigneename,'consigneeadd'=>$conadd,'street'=>$street,
                    'landmark'=>$land,'consigneecity'=>$ccity,'consigneepincode'=>$cpincode,
                    'nog'=>$nog,'qty'=>$cqty,'weight'=>$weight,'remark'=>$remark,'consigneecft'=>$ccft,'bilty'=>$bilty,'freight'=>$freight,'ser'=>$serc,'vtype'=>$vtype,'vno'=>$vlcno,
                    'driver'=>$driver,'licsno'=>$lisc,'sealno'=>$sealno,'risk'=>$risk,'subjectto'=>$subjectto,
                    'mode'=>$tmode,'tdel'=>$tdel,'ddate'=>$ddate,'incno'=>$incno,
                    'incval'=>$incvl,'icomp'=>$icomp,'iamount'=>$iamt,'policyno'=>$policyno,'payableat'=>$payableat,
                    'prisk'=>$irisk,'createdDtm'=>date('Y-m-d H:i:s'),'pdate'=>$indate,'expectedddate'=>$exdate
                    );
                }
                else
                {
                  $indate=NULL;
                  $exdate=date('Y-m-d', strtotime($expdate) );
                  $LrInfo = array('cft'=>$cft,'contactperson'=>$conp,'contactpersonno'=>$conpno,'contactpersonnob'=>$conpnob,'contactpersonnoc'=>$conpnoc,'consigneename'=>$consigneename,'consigneeadd'=>$conadd,'street'=>$street,
                    'landmark'=>$land,'consigneecity'=>$ccity,'consigneepincode'=>$cpincode,
                    'nog'=>$nog,'qty'=>$cqty,'weight'=>$weight,'remark'=>$remark,'consigneecft'=>$ccft,'bilty'=>$bilty,'freight'=>$freight,'ser'=>$serc,'vtype'=>$vtype,'vno'=>$vlcno,
                    'driver'=>$driver,'licsno'=>$lisc,'sealno'=>$sealno,'risk'=>$risk,'subjectto'=>$subjectto,
                    'mode'=>$tmode,'tdel'=>$tdel,'ddate'=>$ddate,'incno'=>$incno,
                    'incval'=>$incvl,'icomp'=>$icomp,'iamount'=>$iamt,'policyno'=>$policyno,'payableat'=>$payableat,
                    'prisk'=>$irisk,'createdDtm'=>date('Y-m-d H:i:s'),'pdate'=>$indate,'expectedddate'=>$exdate
                    );

                }

              }
              else{
                $indate=date('Y-m-d', strtotime($idate) );
                if(empty($expdate))
                {
                  $exdate=NULL;
                $LrInfo = array('cft'=>$cft,'contactperson'=>$conp,'contactpersonno'=>$conpno,'contactpersonnob'=>$conpnob,'contactpersonnoc'=>$conpnoc,'consigneename'=>$consigneename,'consigneeadd'=>$conadd,'street'=>$street,
                    'landmark'=>$land,'consigneecity'=>$ccity,'consigneepincode'=>$cpincode,
                    'nog'=>$nog,'qty'=>$cqty,'weight'=>$weight,'remark'=>$remark,'consigneecft'=>$ccft,'bilty'=>$bilty,'freight'=>$freight,'ser'=>$serc,'vtype'=>$vtype,'vno'=>$vlcno,
                    'driver'=>$driver,'licsno'=>$lisc,'sealno'=>$sealno,'risk'=>$risk,'subjectto'=>$subjectto,
                    'mode'=>$tmode,'tdel'=>$tdel,'ddate'=>$ddate,'incno'=>$incno,'pdate'=>$indate,
                    'incval'=>$incvl,'icomp'=>$icomp,'iamount'=>$iamt,'policyno'=>$policyno,'payableat'=>$payableat,
                    'prisk'=>$irisk,'createdDtm'=>date('Y-m-d H:i:s'),'expectedddate'=>$exdate
                    );
              }
              else
              {
                $exdate=date('Y-m-d', strtotime($expdate) );
                $LrInfo = array('cft'=>$cft,'contactperson'=>$conp,'contactpersonno'=>$conpno,'contactpersonnob'=>$conpnob,'contactpersonnoc'=>$conpnoc,'consigneename'=>$consigneename,'consigneeadd'=>$conadd,'street'=>$street,
                    'landmark'=>$land,'consigneecity'=>$ccity,'consigneepincode'=>$cpincode,
                    'nog'=>$nog,'qty'=>$cqty,'weight'=>$weight,'remark'=>$remark,'consigneecft'=>$ccft,'bilty'=>$bilty,'freight'=>$freight,'ser'=>$serc,'vtype'=>$vtype,'vno'=>$vlcno,
                    'driver'=>$driver,'licsno'=>$lisc,'sealno'=>$sealno,'risk'=>$risk,'subjectto'=>$subjectto,
                    'mode'=>$tmode,'tdel'=>$tdel,'ddate'=>$ddate,'incno'=>$incno,'pdate'=>$indate,
                    'incval'=>$incvl,'icomp'=>$icomp,'iamount'=>$iamt,'policyno'=>$policyno,'payableat'=>$payableat,
                    'prisk'=>$irisk,'createdDtm'=>date('Y-m-d H:i:s'),'expectedddate'=>$exdate
                    );

              }
              }

                $this->load->model('lr_model');
                $result = $this->lr_model->updatelr($LrInfo,$lrno);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'LR Updated Successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'LR Update Failed');
                }
                
                redirect('lrlisting');
            }
        
    }
/*Editexlr ends*/


/**
     * This function is used to delete the LR using Lrno
     * @return boolean $result : TRUE / FALSE
     */
    function deletelr()
    {
        if($this->isAdmin() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $lrno = $this->input->post('lrid');
            $lrInfo = array('isDeleted'=>1,'updatedBy'=>$this->vendorId, 'updatedDtm'=>date('Y-m-d H:i:s'));
            
            $result = $this->lr_model->deletelr($lrno,$lrInfo);
            
            if ($result>0) 
                {
                 echo(json_encode(array('status'=>TRUE))); 
             }

            else { echo(json_encode(array('status'=>FALSE))); 
        }
        
        }
    }

function lrreport()
{
           
            $data['lrinfoc']=$this->lr_model->getalllrinfo();
            $this->global['pageTitle'] = 'Shaurya Enterprises : Lr Report';
            $this->loadViews("lrreportd", $this->global, $data, NULL);
}

function getlrreport()
{

            $this->load->library('form_validation');
            $this->form_validation->set_rules('fromdate','date','required|max_length[100]');
            $this->form_validation->set_rules('todate','date','required|max_length[100]');
            $this->form_validation->set_rules('customer','customer','required|max_length[100]');
            
            if($this->form_validation->run() == FALSE)
        {
            $this->session->set_flashdata('error','Please select valid date and customer');

            redirect('lrreport');
        }

         $val=$this->input->post();
             $fromdate=$val['fromdate'];
             $todate=$val['todate'];



          $cust = $this->input->post('customer');

          $data['fdate']=$val['fromdate'];
             $data['tdate']=$val['todate'];
             $data['customer']=$this->input->post('customer');


          $data['lrinfo'] = $this->lr_model->getLrbycustomer($cust,$fromdate,$todate);
          $data['lrinfoc']=$this->lr_model->getalllrinfo();

          $this->global['pageTitle'] = 'Shaurya Enterprises : Lr Report';
          $this->loadViews("lrreportd", $this->global, $data, NULL);
}


}
?>