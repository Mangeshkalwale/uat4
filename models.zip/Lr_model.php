<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Lr_model extends CI_Model
{

/**
     * This function is used to create new lr
     * @return number $insert_id : This is last inserted id
     */
    function addNewlr($LrInfo)
    
    {
        $this->db->trans_start();
        $this->db->insert('tbl_lr', $LrInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }


    /**
     * This function used to get lr information by id
     * @param number $id : This is customer id
     * @return array $result : This is customer information
     */
    function getlrInfo($id)     
    {
          
        $this->db->select('*');
        $this->db->from('tbl_lr');
        
        $this->db->where('lrno', $id);
        $query = $this->db->get();
        
        return $query->result();
    }
    function getlrInfoftv($id)     
    {
          
        $this->db->select('city,consigneecity,vtype');
        $this->db->from('tbl_lr');
        
        $this->db->where('lrno', $id);
        $query = $this->db->get();
        
        return $query->row();
    }
    function getfreightc($fromc,$toc,$vtype,$custid)
    {
      $this->db->select('freightrate');
        $this->db->from('tbl_freight');
        
        $this->db->where('fromc',$fromc);
        $this->db->where('toc',$toc);
        $this->db->where('vehicle',$vtype);
        $this->db->where('custid',$custid);
        
        $this->db->where('isDeleted', 0);
        $query = $this->db->get();
        
        return $query->row();

    }

    function getsaccode()
    {
        $this->db->select( 'saccode');
        $this->db->from('sac');
        $query = $this->db->get();
        return $query->row();


    }




    /*this function is for getlrinfo of selected lr*/


    /**
     * This function used to get lr information by id
     * @param number $id : This is customer id
     * @return array $result : This is customer information
     */
    function getselectedlrInfo($id)

    {

        $this->db->select('*');
        $this->db->from('tbl_lr');
        $this->db->where_in('lrno', $id);
        $query = $this->db->get();
        
        return $query->result();
    }
    function getlrInfomail($lrno)
    {
       $this->db->select('*');
        $this->db->from('tbl_lr');
        $this->db->where_in('lrno', $lrno);
        $query = $this->db->get();
        
        return $query->row();
    }

     /**
     * This function used to get lr information by name
     * @param number $id : This is customer id
     * @return array $result : This is customer information
     */
    function getLr($cust)
    {
        $this->db->distinct();
        $this->db->select('*');
        $this->db->from('tbl_lr');
        $this->db->where('customername', $cust);
        $this->db->where('invid', NULL);
        $query = $this->db->get();
        
        return $query->result();
    }



    /**
     * This function used to get lr information by id for print
     * @param number $id : This is customer id
     * @return array $result : This is customer information
     */
    function getlrInfop($id)
    {
        $this->db->select('*');
        $this->db->from('tbl_lr');
        $this->db->join('tbl_cust', 'tbl_lr.custid = tbl_cust.id','inner','isDeleted',0);
        $this->db->where('lrno',$id);
        $query = $this->db->get();
        
        return $query->result();
    }


    function getcustInfo($id)
    {
        $this->db->select('*');
        $this->db->from('tbl_cust');
        
        $this->db->where('id',$id);
        $query = $this->db->get();
        
        return $query->row();
    }
    function getlrInfopc($id) /*for contractual customer lr print*/
    {
        $this->db->select('*');
        $this->db->from('tbl_lr');
        $this->db->join('tbl_freight', 'tbl_lr.custid = tbl_freight.custid','inner','isDeleted',0);
        $this->db->where('lrno',$id);
        $query = $this->db->get();
        
        return $query->result();
    }




    function updatelr($LrInfo,$lrno)
    {
        $this->db->set($LrInfo);
        $this->db->where('lrno', $lrno);
        $this->db->update('tbl_lr');
        
        return $this->db->affected_rows();


    }
    function setdeliverystatus($status,$lr)
    {

        $this->db->set($status);
        $this->db->where('lrno', $lr);
        $this->db->update('tbl_lr');
        
        return $this->db->affected_rows();


    }


    function archive($archivelr,$lrno)

    {
        $this->db->set($archivelr);
        $this->db->where('lrno', $lrno);
        $this->db->update('tbl_lr');
        
        return $this->db->affected_rows();


    }

    function unarchive($archivelr,$lrno)

    {
        $this->db->set($archivelr);
        $this->db->where('lrno', $lrno);
        $this->db->update('tbl_lr');
        
        return $this->db->affected_rows();


    }



      /**
     * This function is used to get the user listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is lrTbl.sealno, count
     */
    function lrListingCount($searchText = '')
    {
         $this->db->select('*');


        $this->db->from('tbl_lr as lrTbl');
        /*$this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');*/
        if(!empty($searchText)) {
            $likeCriteria = "(lrTbl.email  LIKE '%".$searchText."%'
                            OR  lrTbl.customername  LIKE '%".$searchText."%'
                            OR  lrTbl.gstno  LIKE '%".$searchText."%'
                            OR  lrTbl.lrno  LIKE '%".$searchText."%')";


            $this->db->where($likeCriteria);
        }
          $this->db->where('lrTbl.isDeleted', 0);
          $this->db->where('lrTbl.archive', 0);
        
        $this->db->order_by('lrTbl.lrno', 'DESC');
        
       
        $query = $this->db->get();
        
        return $query->num_rows();
    }



        /**
     * This function is used to get the lr listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function lrListing($searchText = '', $page, $segment)
    {
        
        $this->db->select('*');
        $this->db->from('tbl_lr as lrTbl');
        /*$this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');*/
        if(!empty($searchText)) {
            $likeCriteria = "(lrTbl.email  LIKE '%".$searchText."%'
                            OR  lrTbl.customername  LIKE '%".$searchText."%'
                            OR  lrTbl.gstno  LIKE '%".$searchText."%'
                             OR  lrTbl.lrno  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        /*$this->db->where('BaseTbl.roleId !=', 1);*/
        

        $this->db->where('lrTbl.isDeleted', 0);
         $this->db->where('lrTbl.archive', 0);
        
        $this->db->order_by('lrTbl.lrno', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();
        if(empty($result))        
        {
            echo"<script>alert('No result found')</script>";
        }
        else
        {
        return $result;    
        }
        
    }



     function lrListingdash($searchText = '', $page, $segment)
    {
        
        $this->db->select('*');
        $this->db->from('tbl_lr as lrTbl');
        /*$this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');*/
        if(!empty($searchText)) {
            $likeCriteria = "(lrTbl.email  LIKE '%".$searchText."%'
                            OR  lrTbl.customername  LIKE '%".$searchText."%'
                            OR  lrTbl.gstno  LIKE '%".$searchText."%'
                             OR  lrTbl.lrno  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        /*$this->db->where('BaseTbl.roleId !=', 1);*/
        

        $this->db->where('lrTbl.isDeleted', 0);
         $this->db->where('lrTbl.archive', 0);
         $this->db->where('lrTbl.status', 'undelivered');
        
        $this->db->order_by('lrTbl.lrno', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();
        if(empty($result))        
        {
            echo"<script>alert('No result found')</script>";
        }
        else
        {
        return $result;    
        }
        
    }



 /**
     * This function is used to get the archived lr listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is lrTbl.sealno, count
     */
    function archlrListingCount($searchText = '')
    {
         $this->db->select('*');


        $this->db->from('tbl_lr as lrTbl');
        /*$this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');*/
        if(!empty($searchText)) {
            $likeCriteria = "(lrTbl.email  LIKE '%".$searchText."%'
                            OR  lrTbl.customername  LIKE '%".$searchText."%'
                            OR  lrTbl.gstno  LIKE '%".$searchText."%'
                            OR  lrTbl.lrno  LIKE '%".$searchText."%')";


            $this->db->where($likeCriteria);
        }
          $this->db->where('lrTbl.isDeleted', 0);
          $this->db->where('lrTbl.archive', 1);
        
        $this->db->order_by('lrTbl.lrno', 'DESC');
        
       
        $query = $this->db->get();
        
        return $query->num_rows();
    }


        /**
     * This function is used to get the lr listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function archlrListing($searchText = '', $page, $segment)
    {
        $this->db->select('*');
        $this->db->from('tbl_lr as lrTbl');
        /*$this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');*/
        if(!empty($searchText)) {
            $likeCriteria = "(lrTbl.email  LIKE '%".$searchText."%'
                            OR  lrTbl.customername  LIKE '%".$searchText."%'
                            OR  lrTbl.gstno  LIKE '%".$searchText."%'
                             OR  lrTbl.lrno  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        /*$this->db->where('BaseTbl.roleId !=', 1);*/
        

        $this->db->where('lrTbl.isDeleted', 0);
        $this->db->where('lrTbl.archive', 1);
        
        $this->db->order_by('lrTbl.lrno', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();
        if(empty($result))        
        {
            echo"<script>alert('No result found')</script>";
        }
        else
        {
        return $result;    
        }
        
    }

    









     /**
     * This function is used to delete the LR information
     * @param number $userId : This is user id
     * @return boolean $result : TRUE / FALSE
     */
    function deletelr($lrno, $lrInfo)
    {
        $this->db->where('lrno', $lrno);
        $this->db->update('tbl_lr', $lrInfo);
        
        return $this->db->affected_rows();
    }

    function insertinvoiceid($invoiceid,$lrno)
    {
       
        $this->db->set($invoiceid);
        $this->db->where_in('lrno', $lrno);
        $this->db->update('tbl_lr');
        
        return $this->db->affected_rows();
           # code...
       

    }




 /**
     * This function is used to get the lr listing count for invoice whoes invoice is not generated
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function lrListingforinvoice($searchText = '', $page, $segment)
    {
        $this->db->distinct();
        $this->db->select('lrTbl.customername');
        $this->db->from('tbl_lr as lrTbl');
        /*$this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');*/
        if(!empty($searchText)) {
            $likeCriteria = "(lrTbl.email  LIKE '%".$searchText."%'
                            OR  lrTbl.customername  LIKE '%".$searchText."%'
                            OR  lrTbl.gstno  LIKE '%".$searchText."%'
                             OR  lrTbl.lrno  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        /*$this->db->where('BaseTbl.roleId !=', 1);*/
        

        $this->db->where('lrTbl.isDeleted', 0);
        $this->db->where('lrTbl.invid',NULL);
         $this->db->where('lrTbl.archive', 0);
        
        $this->db->order_by('lrTbl.lrno', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();
        if(empty($result))        
        {
            echo"<script>alert('No result found')</script>";
        }
        else
        {
        return $result;    
        }
        
    }


    /**
     * This function used to get lr information by id
     * @param number $id : This is customer id
     * @return array $result : This is customer information
     */
    function getselectedlrInfoinv($id)

    {

        $this->db->select('*');
        $this->db->from('tbl_lr');
        
        $this->db->where_in('invid',$id);
        $query = $this->db->get();
        
        return $query->result();
    }



    function getalllrinfo()
    {
        $this->db->distinct();
        $this->db->select('customername');
        $this->db->from('tbl_lr');
         $query = $this->db->get();
         return $query->result();

    }

    function getacrlrinfo()
    {
        
        $this->db->select('distinct(lrno),customername');
        $this->db->from('tbl_lr');
        $this->db->group_by('lrno');

        $query = $this->db->get();
        return $query->result();

    }

     function getLrbycustomer($cust,$datefrom,$dateto)
    {
        $this->db->select('*');
        $this->db->from('tbl_lr');
        $this->db->where('customername', $cust);
        $this->db->where('createdDtm BETWEEN "'. $datefrom. '" and "'. $dateto.'"');
       
        
        $query = $this->db->get();
        
        return $query->result();
    }

    function getinvoice($lrno)
    {
        $this->db->select('invid');
        $this->db->from('tbl_lr');
        $this->db->where('lrno',$lrno);
        $this->db->where('invid is not null');

       
        $query=$this->db->get();
         return $query->num_rows();

    }


function getbalancedue($lrno)
{
    $this->db->select('balancedue');
      $this->db->from('invoice');
       $this->db->join('tbl_lr', 'invoice.invid = tbl_lr.invid','inner','isDeleted',0);
      $this->db->where('tbl_lr.lrno', $lrno);
      $query = $this->db->get();
        $info=$query->row();
        return $info->balancedue;


}
function getcustid($lrno)
{
    $this->db->select('*');
      $this->db->from('tbl_lr');
       
      $this->db->where_in('lrno', $lrno);
      $query = $this->db->get()->row()->custid;
        
        return $query;


}
function getfromcity($lrno)
{
    $this->db->select('city');
      $this->db->from('tbl_lr');
       
      $this->db->where_in('lrno', $lrno);
      $query = $this->db->get()->row()->city;
        
        return $query;


}
function gettocity($lrno)
{

    $this->db->select('consigneecity');
      $this->db->from('tbl_lr');
       
      $this->db->where_in('lrno', $lrno);
      $query = $this->db->get()->row()->consigneecity;
        
        return $query;

}
function getcusttype($getcustid)
{

    $this->db->select('customertype');
      $this->db->from('tbl_cust');
       
      $this->db->where_in('id', $getcustid);
      $query = $this->db->get()->row()->customertype;
        
        return $query;

}

function getvtype($lrno)
{

    $this->db->select('vtype');
      $this->db->from('tbl_lr');
       
      $this->db->where_in('lrno', $lrno);
      $query = $this->db->get()->row()->vtype;
        
        return $query;

}
function getfreight($getcustid,$getfromcity,$gettocity,$getvtype)
{

      $this->db->select('freightrate');
      $this->db->from('tbl_freight');
      $this->db->join('tbl_cust', 'tbl_cust.id = tbl_freight.custid','inner');
      $this->db->where_in('tbl_freight.custid', $getcustid);

      $this->db->where_in('tbl_freight.fromc', $getfromcity);
      $this->db->where_in('tbl_freight.toc', $gettocity);
      $this->db->where_in('tbl_freight.vehicle',$getvtype);
    
      
     $query = $this->db->get();
    return $query->row();

     /*  
    
      $query = $this->db->get();
      return $query->result(); 
       
      
      return $query->result();*/




}

function  insf($lrno,$cft)
{
  $this->db->set($cft);
        $this->db->where_in('lrno', $lrno);
        $this->db->update('tbl_lr');
        
        return $this->db->affected_rows();

}








}