<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class invoice_model extends CI_Model
{





public function getinvoiceid()
{
	
       $lastId = $this->db->insert_id();

}


public function saveinvoice($invdata)
{
		$this->db->trans_start();
        $this->db->insert('invoice', $invdata);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
 }

/**
     * This function is used to get the user listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is lrTbl.sealno, count
     */
    function invListingCount($searchText = '')
    {
         $this->db->select('invTbl.invid,invTbl.date,invTbl.lrcharges,invTbl.gst,invTbl.subtotal,invTbl.total,invTbl.balancedue');


        $this->db->from('invoice as invTbl');
        $this->db->join('tbl_lr', 'invTbl.invid = tbl_lr.invid','inner','isDeleted',0);
        
        /*$this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');*/
        if(!empty($searchText)) {
            $likeCriteria = "(invTbl.invid  LIKE '%".$searchText."%'
                              OR tbl_lr.customername  LIKE '%".$searchText."%'
                              OR tbl_lr.lrno  LIKE '%".$searchText."%'
                              )";



            $this->db->where($likeCriteria);
        }
          
         
          $this->db->where('isarchive',0);
        $this->db->order_by('invTbl.invid', 'DESC');
        
       
        $query = $this->db->get();
        
        return $query->num_rows();
    }
    

     /**
     * This function is used to get the lr listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function invListing($searchText = '', $page, $segment)
    {
        
        $this->db->select('*');
        $this->db->from('invoice as invTbl');
        $this->db->join('tbl_lr', 'invTbl.invid = tbl_lr.invid','inner','isDeleted',0);
        if(!empty($searchText)) {
            $likeCriteria = "(invTbl.invid  LIKE '%".$searchText."%'
                              OR tbl_lr.customername  LIKE '%".$searchText."%'
                              OR tbl_lr.lrno  LIKE '%".$searchText."%'
                              )";
            $this->db->where($likeCriteria);
        }
        
        /*$this->db->where('BaseTbl.roleId !=', 1);*/
        /*$this->db->where('isDeleted',0);*/
        $this->db->where('isarchive',0);
        $this->db->group_by('invTbl.invid');
        $this->db->order_by('invTbl.invid', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();
        if(empty($result))        
        {
            
                    $this->session->set_flashdata('error', 'No records found');
                    print_r($result); 
                
        }
        else
        {
        return $result;    
        }
        
    }

public function getinvoicebyid($id)
{
	$this->db->select('*');
        $this->db->from('invoice');
        $this->db->join('tbl_lr', 'tbl_lr.invid = invoice.invid','inner');
        $this->db->where('invoice.invid', $id);
        $query = $this->db->get();
        
        return $query->result();
}


public function getinvoicebyidsingle($id)
{
    $this->db->select('*');
        $this->db->from('invoice');
        

        $this->db->join('tbl_lr', 'tbl_lr.invid = invoice.invid','inner');
        $this->db->where('invoice.invid', $id);
        $this->db->limit(1);
        $query = $this->db->get();
        
        return $query->result();
}

public function getinvoicebyidformail($id)
{
    $this->db->select('*');
        $this->db->from('invoice');
        

        $this->db->join('tbl_lr', 'tbl_lr.invid = invoice.invid','inner');
        $this->db->where('invoice.invid', $id);
        $this->db->limit(1);
        $query = $this->db->get();
        
        return $query->row();
}


public function getsinvoicebyid($id)
{
	$this->db->select('*');
        $this->db->from('invoice');
        

        
        $this->db->where('invid', $id);
        $query = $this->db->get();
        
        return $query->result();
}
public function getdueinvoice($tdate)
{
  $this->db->select('*');
        $this->db->from('invoice');
        $this->db->where('duedate<=', $tdate);
        $this->db->join('tbl_lr', 'invoice.invid = tbl_lr.invid','inner','isDeleted',0);
        $this->db->where('balancedue >',0);
        
        $query = $this->db->get();
        
        return $query->result();
}


public function getinvoiceto($id)
{
	$this->db->select('*');
        $this->db->from('tbl_lr');
        $this->db->where('invid', $id);
        $this->db->limit(1);
        $query = $this->db->get();
        
        return $query->result();


}

function getbalancedue($invid)
{
    $this->db->select('balancedue');
      $this->db->from('invoice');
      $this->db->where('invid', $invid);
      $query = $this->db->get();
        $info=$query->row();
        return $info->balancedue;


}



 /**
     * This function is used to delete the LR information
     * @param number $userId : This is user id
     * @return boolean $result : TRUE / FALSE
     */
    function deleteinv($invno,$invInfo)
    {
        $this->db->where('invid', $invno);
        $this->db->update('invoice', $invInfo);
        
        return $this->db->affected_rows();
    }


function setinvid($invno,$invidInfo)
{
     $this->db->set($invidInfo);
     $this->db->where('invid', $invno);
    $this->db->update('tbl_lr');
        
        return $this->db->affected_rows();

}




function updateinvoice($invdata,$invid)
{
    $this->db->set($invdata);
     $this->db->where('invid',$invid);
    $this->db->update('invoice');
    return $this->db->affected_rows();

}

 function archive($invid,$invdata)
 {
     $this->db->where('invid',$invid);
    $this->db->update('invoice',$invdata);
    return $this->db->affected_rows();

 }

 function unarchive($invid,$invdata)
 {
     $this->db->where('invid',$invid);
    $this->db->update('invoice',$invdata);
    return $this->db->affected_rows();

 }


 /*archived invoide starts here*/

/**
     * This function is used to get the user listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is lrTbl.sealno, count
     */
    function ainvListingCount($searchText = '')
    {
         $this->db->select('*');


        $this->db->from('invoice as invTbl');
        $this->db->join('tbl_lr', 'invTbl.invid = tbl_lr.invid','inner','isDeleted',0);
        /*$this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');*/
        if(!empty($searchText)) {
            $likeCriteria = "(invTbl.invid  LIKE '%".$searchText."%')";


            $this->db->where($likeCriteria);
        }
          
          
          $this->db->where('isarchive',1);
        $this->db->order_by('invTbl.invid', 'DESC');
        
       
        $query = $this->db->get();
        
        return $query->num_rows();
    }
    

     /**
     * This function is used to get the lr listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function ainvListing($searchText = '', $page, $segment)
    {
        
         $this->db->select('*');
        $this->db->from('invoice as invTbl');
        $this->db->join('tbl_lr', 'invTbl.invid = tbl_lr.invid','inner','isDeleted',0);
        if(!empty($searchText)) {
            $likeCriteria = "(invTbl.invid  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        /*$this->db->where('BaseTbl.roleId !=', 1);*/
        /*$this->db->where('isDeleted',0);*/
        $this->db->where('isarchive',1);
        
        $this->db->order_by('invTbl.invid', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();
        if(empty($result))        
        {
            
                    $this->session->set_flashdata('error', 'No records found');
                    print_r($result); 
                
        }
        else
        {
        return $result;    
        }
        
    }

 /*archived invoice ends here*/

     function insertinvoiceid($invoiceid)
    {
        $this->db->trans_start();

      $this->db->insert('payment', $invoiceid);
      $this->db->trans_complete();
        
        return $this->db->affected_rows();

    }


function getpaymentmode()
    {
       $this->db->select('*');
        $this->db->from('paymentmode');
       
      
        $query = $this->db->get();
        
        return $query->result();

    }

    function getpaymentinfo($searchText = '', $page, $segment)
    {
      $this->db->select('*');
        $this->db->from('payment as pTbl');
        $this->db->join('tbl_lr', 'pTbl.invid = tbl_lr.invid','inner');
        if(!empty($searchText)) {
            $likeCriteria = "(pTbl.invid  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        /*$this->db->where('BaseTbl.roleId !=', 1);*/
        
        /*$this->db->where('isDeleted',0);*/
       /* $this->db->where('isarchive',0);*/
        
        $this->db->order_by('pTbl.invid', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();
        if(empty($result))        
        {
            
                    $this->session->set_flashdata('error', 'No records found');
                    print_r($result); 
                
        }
        else
        {
        return $result;    
        }
    }



function updatepaymentinfo($invid,$payment)
{

    $this->db->set($payment);
     $this->db->where('invid', $invid);
    $this->db->update('payment');
        
     return $this->db->affected_rows();

}

function getpaymentprint($invid)
{
    $this->db->select('*');
        $this->db->from('payment');
        $this->db->join('invoice', 'payment.invid = invoice.invid','inner');
        $this->db->where('payment.invid', $invid);

        $query = $this->db->get();
        
        return $query->result();

}

function updatedue($invid,$setbalancedue)
{
$this->db->set($setbalancedue);
     $this->db->where('invid', $invid);
    $this->db->update('invoice');
        
     return $this->db->affected_rows();


}





/**
     * This function is used to get the payments record count
     * @param string $searchText : This is optional search text
     * @return number $count : This is lrTbl.sealno, count
     */
    function getpaymentinfocount($searchText = '')
    {
         $this->db->select('*');


        $this->db->from('payment as pTbl');
        /*$this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');*/
        if(!empty($searchText)) {
            $likeCriteria = "(pTbl.invid  LIKE '%".$searchText."%')";


            $this->db->where($likeCriteria);
        }
          
          /*$this->db->where('isDeleted',0);*/
         /* $this->db->where('isarchive',0);*/
        $this->db->order_by('pTbl.invid', 'DESC');
        
       
        $query = $this->db->get();
        
        return $query->num_rows();
    }

public function getreports($cust,$datefrom,$dateto)
{
    $this->db->distinct();
    $this->db->select('*');
        $this->db->from('invoice');
       
        $this->db->join('tbl_lr', 'tbl_lr.invid = invoice.invid','inner');
        $this->db->where('tbl_lr.customername', $cust);
        
        $this->db->where('invoice.date BETWEEN"'.$datefrom. '"and"'.$dateto.'"');
    
        $query = $this->db->get();
    
        return $query->result();
}


function getbalanceamount($datefrom,$dateto)
{

    $this->db->select_sum('balancedue');
    $this->db->select_sum('total');
    $this->db->select('customername');
      $this->db->from('invoice');
       $this->db->join('tbl_lr', 'tbl_lr.invid = invoice.invid','inner');
    
      $this->db->where('invoice.date BETWEEN "'. $datefrom. '" and "'. $dateto.'"');
      $this->db->group_by('tbl_lr.customername');
      $query = $this->db->get();
      return $query->result();
}

function getbalancecount($datefrom,$dateto)
{

    $this->db->select('customername',COUNT('customername'));
      $this->db->from('tbl_lr');
       $this->db->join('invoice', 'tbl_lr.invid = invoice.invid','inner');
    
      $this->db->where('invoice.date BETWEEN "'. $datefrom. '" and "'. $dateto.'"');
      
      $this->db->group_by('customername');
      $query = $this->db->get();
      return $query->num_rows();
}

function checktransid($transid)
{
    $this->db->select('transactionid');
    $this->db->from('payment');
    $this->db->where('transactionid',$transid);
    $query = $this->db->get();
    return $query->num_rows();
}




}
