<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Cust_model extends CI_Model
{
/**
     * This function is used to add new customer to system
     * @return number $insert_id : This is last inserted id
     */
    function addNewUser($CustomerInfo)
    
    {
        $this->db->trans_start();
        $this->db->insert('tbl_cust', $CustomerInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    
    function addfreight($freightdata)
    {
         $this->db->trans_start();
        $this->db->insert('tbl_freight',$freightdata);
        
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;


    }

    function deletefre($fid, $freinfo)
    {
        $this->db->where('fid', $fid);
        $this->db->update('tbl_freight',$freinfo);
        
        return $this->db->affected_rows();
    }
/**
     * This function is used to get the user roles information
     * @return array $result : This is result of the query
     */
    function getUserRoles()
    {
        $this->db->select('roleId, role');
        $this->db->from('tbl_roles');
        $this->db->where('roleId !=', 1);
        $query = $this->db->get();
        
        return $query->result();
    }

      /**
     * This function is used to get the user listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function custListingCount($searchText = '')
    {
         $this->db->select('CustTbl.id, CustTbl.customername,CustTbl.address1,CustTbl.address2,CustTbl.city,CustTbl.state,CustTbl.pan,CustTbl.pincode,CustTbl.email,CustTbl.gstno,CustTbl.ccft,CustTbl.contactperson,CustTbl.contactperson,CustTbl.conpersonno');
        $this->db->from('tbl_cust as CustTbl');
        /*$this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');*/
        if(!empty($searchText)) {
            $likeCriteria = "(CustTbl.email  LIKE '%".$searchText."%'
                            OR  CustTbl.customername  LIKE '%".$searchText."%'
                            OR  CustTbl.gstno  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
          $this->db->where('CustTbl.isDeleted', 0);
        
        $this->db->order_by('CustTbl.id', 'DESC');
        
       
        $query = $this->db->get();
        
        return $query->num_rows();
    }
    
    /**
     * This function is used to get the user listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function custListing($searchText = '', $page, $segment)
    {
        $this->db->select('CustTbl.id, CustTbl.customername,CustTbl.address1,CustTbl.address2,CustTbl.city,CustTbl.state,CustTbl.pan,CustTbl.pincode,CustTbl.email,CustTbl.gstno,CustTbl.ccft,CustTbl.contactperson,CustTbl.conpersonno');
        $this->db->from('tbl_cust as CustTbl');
        /*$this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');*/
        if(!empty($searchText)) {
            $likeCriteria = "(CustTbl.email  LIKE '%".$searchText."%'
                            OR  CustTbl.customername  LIKE '%".$searchText."%'
                            OR  CustTbl.gstno  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        
        /*$this->db->where('BaseTbl.roleId !=', 1);*/
        

        $this->db->where('CustTbl.isDeleted', 0);
        
        $this->db->order_by('CustTbl.id', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();
        if(empty($result))        
        {
            echo"<script>alert('No result found')</script>";
        }
        else
        {
        return $result;    
        }
        
    }
   /**
     * This function is used to update the customer information
     * @param array $userInfo : This is users updated information
     * @param number $userId : This is user id
     */
    function editcust($custInfo, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('tbl_cust', $custInfo);
        
        return TRUE;
    }
    /**
     * This function is used to delete the user information
     * @param number $userId : This is user id
     * @return boolean $result : TRUE / FALSE
     */
    function deletecust($custId, $custInfo)
    {
        $this->db->where('id', $custId);
        $this->db->update('tbl_cust', $custInfo);
        
        return $this->db->affected_rows();
    }


public function cust_exists($gstno)
{   
       $this->db->select("gstno");
       $this->db->from("tbl_cust");
       $this->db->where("gstno",$gstno);
        $query = $this->db->get();

        return $query->num_rows();
   
}

public function cust_existsmail($email)
{   
       $this->db->select("*");
       $this->db->from("tbl_cust");
       $this->db->where("email",$email);
       $this->db->where("isDeleted",0);
        $query = $this->db->get();

        return $query->num_rows();
   
}
public function cust_existsumail($email)
{   
       $this->db->select("*");
       $this->db->from("tbl_users");
       $this->db->where("email",$email);
       $this->db->where("isDeleted",0);
        $query = $this->db->get();

        return $query->num_rows();
   
}

public function cust_mail($id)
{

       $this->db->select("email");
       $this->db->from("tbl_cust");
       $this->db->where("id",$id);

       $this->db->where("isDeleted",0);
       $query = $this->db->get()->row()->email;
       return $query;


}
public function cust_gstno($id)
{

       $this->db->select("gstno");
       $this->db->from("tbl_cust");
       $this->db->where("id",$id);

       $this->db->where("isDeleted",0);
       $query = $this->db->get()->row()->gstno;
       return $query;


}
public function getfreight($id)
{
     $this->db->select("*");
       $this->db->from("tbl_freight");
       $this->db->join('tbl_cust', 'tbl_freight.custid = tbl_cust.id','inner');
       $this->db->where("custid",$id);
       $this->db->where("tbl_freight.isDeleted",0);
       $this->db->where("tbl_cust.isDeleted",0);
       $query = $this->db->get();
       return $query->result();

}
public function getfreightrec($id)
{
     $this->db->select("*");
       $this->db->from("tbl_freight");
       $this->db->where("fid",$id);
       $this->db->where("isDeleted",0);
       $query = $this->db->get();
       return $query->row();

}

function updatefreight($id,$updatefret)
{
    $this->db->set($updatefret);
     $this->db->where('fid', $id);
    $this->db->update('tbl_freight');
        
        return $this->db->affected_rows();


}

function getfreightdetails($vehicle,$fromcity,$tocity,$custid)
{
  $this->db->select("*");
       $this->db->from("tbl_freight");
       $this->db->where_in("custid",$custid);
       $this->db->where_in("vehicle",$vehicle);
       $this->db->where_in("fromc",$fromcity);
       $this->db->where_in("toc",$tocity);
       $this->db->where("isDeleted",0);
       $query = $this->db->get();
       return $query->num_rows();
     

}

    


}